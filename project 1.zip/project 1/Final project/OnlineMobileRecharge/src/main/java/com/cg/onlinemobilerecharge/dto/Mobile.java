package com.cg.onlinemobilerecharge.dto;

import java.math.BigInteger;

public class Mobile
{

	public Mobile(BigInteger mobileno, String operator) 
	{
		super();
		this.mobileno = mobileno;
		this.operator = operator;
	}
	public Mobile()
	{
		super();

	}
	private  BigInteger mobileno;
	private String operator;
	public BigInteger getMobileno() 
	{
		return mobileno;
	}
	public void setMobileno(BigInteger mobileno) 
	{
		this.mobileno = mobileno;
	}
	public String getOperator() 
	{
		return operator;
	}
	public void setOperator(String operator)
	{
		this.operator = operator;
	}
	@Override
	public String toString()
	{
		return "Mobile [mobileno=" + mobileno + ", operator=" + operator + "]";
	}
	
	
	
}
