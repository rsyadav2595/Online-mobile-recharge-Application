package com.cg.onlinemobilerecharge.dto;

import java.util.List;

public class Customer
 {
	
	public Customer(String name, String email, List<Mobile> mobiles) 
	{
		super();
		this.name = name;
		this.email = email;
		this.mobiles = mobiles;
	}
	public Customer() 
	{
		super();

	}
	   private String name;
	   private String email;
	   private List<Mobile>mobiles;
	public String getName() 
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public List<Mobile> getMobiles() 
	{
		return mobiles;
	
	}
	public void setMobiles(List<Mobile> mobiles)
	{
		this.mobiles = mobiles;
	}
	@Override
	public String toString() 
	{
		return "Customer [name=" + name + ", email=" + email + ", mobiles=" + mobiles + "]";
	}
	public void add(Customer custm) {

	}
	
	
	
	
	
 }
    