package com.cg.onlinemobilerecharge.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.service.MobileRechargeService;
import com.cg.onlinemobilerecharge.service.MobileRechargeServiceImpl;
import com.cg.onlinemobilerecharge.util.DbUtil;

public class MyApplication {

	static  MobileRechargeService  service;
	public  MyApplication()
	{
		
	}
	
	public static void main(String[] args)
	{
  Scanner sc=new Scanner(System.in);	
	    service=new MobileRechargeServiceImpl();
	    int choice=0;
	    do {
	    	printdetails();
	    	System.out.println("Enter choice");
	    	choice=sc.nextInt();
	    	switch(choice)
	    	{
	    	case 1:
	    		List<Mobile> mobiles=new ArrayList<>();
 		         System.out.println("Enter the name");
	    	    String name=sc.next();
	    	    System.out.println("Enter the email");
	    	    String email=sc.next();
	    	    System.out.println("Enter the mobile no");
	    	    System.out.println("ebnter operator");
	    	    String operator=sc.next();
	    	    BigInteger mobile=sc.nextBigInteger();
	    	    Mobile mobi =new Mobile();
	    	    mobi.setMobileno(mobile);
	    	    mobi.setOperator(operator);
	    	    mobiles.add(mobi);
	    	    
	      //  Customer custm =Customer(name,email, mobiles) ;
	    	    
	    	    Customer custm =new Customer();
	    	    custm.setName(name);
	    	    custm.setEmail(email);
	    	    custm.setMobiles(mobiles);
	    	    
	    	    
	    	    
	              List<Mobile> mylist = DbUtil.mylist;
	              custm.setMobiles(mylist);
	              
	              List<Customer> custmlist = DbUtil.custmlist;
	              service.addCustomer(custm);
	        
	              
	    
	                break;
	                
	                
	    	  case 2: 
	    		System.out.println("Enter balance");
	    		BigDecimal balance=sc.nextBigDecimal();
	    		
	    		   System.out.println("Enter customer name");
	    		  String customer =sc.next();
	    		   Wallet wallet=new Wallet();
	    	   
	    	       wallet.setBalance(balance);
	    	      
	           
	           break;
	           
	           
	           
	           
	           
	           
	    case 3:
	    	
	     
	    	  
	    	  
	    	  
	    	  
	      case 4:
	    	   System.out.println("Enter mobile no");
	    	   BigInteger mobileno =sc.nextBigInteger();
	    	   
	    	   Mobile mobilesearch =service.searchByMobileno(mobileno);
	  
	    	   for (Customer customer : DbUtil.custmlist) {
				System.out.println("mobile no is"+customer.getMobiles());
		
	    	   }    	   
   
	    	    break;
	   
	    	    
	    case 5:
	    	    
	    	    
	    	}
	    	
	    
	    }  while(choice!=6); 
	    	
	    	
	    
			
			
			
			}


	private static void printdetails() 
	{

		
		System.out.println("1. Add Customer");
		System.out.println("2. Create Wallet");
		System.out.println("3. Topup balance");
		System.out.println("4. Search by mobile no");
		System.out.println("5. Reacharge mobile no");
		
	}
	
}