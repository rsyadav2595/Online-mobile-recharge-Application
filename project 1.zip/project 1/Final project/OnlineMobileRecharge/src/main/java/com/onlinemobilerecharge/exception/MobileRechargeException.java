package com.onlinemobilerecharge.exception;

public class MobileRechargeException extends RuntimeException {


	public MobileRechargeException()
	{
		
	}
	

	public MobileRechargeException(String msg)
	{
		super( msg);
		}
}
