package com.cg.onlinemobilerecharge.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dao.MobileRechargeRepository;
import com.cg.onlinemobilerecharge.dao.MobileRechargeRepositoryImpl;
import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.util.DbUtil;
import com.onlinemobilerecharge.exception.MobileRechargeException;

public class MobileRechargeServiceImpl implements  MobileRechargeService 
{
	MobileRechargeRepository repository;
	
	  public MobileRechargeServiceImpl()
	  {
		  repository= new MobileRechargeRepositoryImpl();
	  }
	
	
	
	
	public boolean addCustomer(Customer custm)
	{
	    if(repository.save(custm))
		 {
	     	return true;
		 }
		   return false;
	
	
	
	}

	public Wallet createWallet(BigDecimal wallet) 
	{
	
		return null;
	}

	public Wallet topupBalance(BigDecimal balance)
	{
		
		return  repository.saveWallet(balance);
	}

	public Mobile searchByMobileno(BigInteger mobileno) throws MobileRechargeException
	{
		
		
		return   repository.findByMobileno(mobileno);
			
	}

	public Wallet rechargeMobile(BigDecimal amount) 
	{
		
		return null;
	}

}
