package com.cg.onlinemobilerecharge.dto;

import java.math.BigDecimal;
import java.util.List;

public class Wallet
{

	
	public Wallet(BigDecimal balance, Customer customer)
	{
		super();
		this.balance = balance;
		this.customer = customer;
		
	}
	public Wallet()
	{
		super();

	}
	private BigDecimal balance;
	private Customer customer;

	public BigDecimal getBalance()
	{
		return balance;
	}
	public void setBalance(BigDecimal balance)
	{
		this.balance = balance;
	}
	public Customer getCustomer()
	{
		return customer;
	}
	public void setCustomer(Customer customer) 
	{
		this.customer = customer;
	}
	
	@Override
	public String toString() 
	{
		return "Wallet [balance=" + balance + ", customer=" + customer +  "]";
	}
}
