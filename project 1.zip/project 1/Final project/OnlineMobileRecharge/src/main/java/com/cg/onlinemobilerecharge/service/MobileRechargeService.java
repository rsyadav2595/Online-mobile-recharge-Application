package com.cg.onlinemobilerecharge.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;

public interface MobileRechargeService 
{

	public boolean addCustomer(Customer custm);
	public Wallet  createWallet(BigDecimal wallet);
	public Wallet  topupBalance(BigDecimal balance);
	public Mobile searchByMobileno(BigInteger mobileno);
    public  Wallet  rechargeMobile(BigDecimal amount);





}
