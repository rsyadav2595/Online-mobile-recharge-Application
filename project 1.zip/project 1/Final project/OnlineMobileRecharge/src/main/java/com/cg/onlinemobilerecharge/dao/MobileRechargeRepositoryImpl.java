package com.cg.onlinemobilerecharge.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;


import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
import com.cg.onlinemobilerecharge.dto.Wallet;
import com.cg.onlinemobilerecharge.util.DbUtil;
import com.onlinemobilerecharge.exception.MobileRechargeException;

public class MobileRechargeRepositoryImpl implements MobileRechargeRepository
{
	//Customer Custmdata;
	
	public MobileRechargeRepositoryImpl()
	{
		
	}

		
	public boolean save(Customer custm) 
	{
		
		//Custmdata.add(custm);
		
	    DbUtil.custmlist.add(custm);
		return true;
	}

	public Wallet saveWallet(BigDecimal balance)
	{
		
		return null;
	}

	public Mobile findByMobileno(BigInteger mobileno) 
	{		   
	     for (Mobile mobile : DbUtil.mylist) {
		
		if(mobile.getMobileno()==mobileno) {
			return mobile;
		}
		else {
			throw new MobileRechargeException("mobile no not found");
		}
	}
		 return null;
	}
	 
}
