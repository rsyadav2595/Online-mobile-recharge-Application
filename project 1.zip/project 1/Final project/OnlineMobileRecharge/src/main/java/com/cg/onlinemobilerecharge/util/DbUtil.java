package com.cg.onlinemobilerecharge.util;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.cg.onlinemobilerecharge.dto.Customer;
import com.cg.onlinemobilerecharge.dto.Mobile;
public class DbUtil{


	 public static List<Mobile>mylist =new ArrayList<>();
	 public static	 List<Customer>custmlist =new ArrayList<>();
	
	// private DbUtil() {}
	
	static {
	Mobile mobi=   new Mobile(new BigInteger("9421956709"),new String("idea"));
	Mobile mobione=new Mobile(new BigInteger("98657935"),new String("vodafone"));
	Mobile mobitwo=new Mobile(new BigInteger("8424008665"),new String("jio"));
		
	
	
	mylist.add(mobi);
	mylist.add(mobione);
	mylist.add(mobitwo);
	
	
	Customer custmone=new Customer("RAdhika", "radha@gmail.com",mylist );
	Customer custtwo=new Customer(" Sonali", "sona@gmail.com",mylist );
	Customer custthree=new Customer("Anushka", "anu@gmail.com",mylist );
	
	custmlist.add(custmone);
	custmlist.add(custtwo);

	custmlist.add(custthree);

	
	
	

	
	}


}
