package com.cg.onlinemobilerecharge.dto;

import java.math.BigDecimal;
import java.util.Date;

public class RechargeTransaction 
{


public RechargeTransaction(Date date, BigDecimal amount, Wallet wallet, Mobile mobile) 
{
		super();
		this.date = date;
		this.amount = amount;
		this.wallet = wallet;
		this.mobile = mobile;
	}
public RechargeTransaction() 
{
		super();
		// TODO Auto-generated constructor stub
	}
private Date date;
private BigDecimal amount;
private  Wallet wallet;
private Mobile mobile;
public Date getDate() 
{
	return date;
}
public void setDate(Date date)
{
	this.date = date;
}
public BigDecimal getAmount()
{
	return amount;
}
public void setAmount(BigDecimal amount)
{
	this.amount = amount;
}
public Wallet getWallet()
{
	return wallet;
}
public void setWallet(Wallet wallet) 
{
	this.wallet = wallet;
}
public Mobile getMobile() 
{
	return mobile;
}
public void setMobile(Mobile mobile)
{
	this.mobile = mobile;
}
@Override
public String toString()
{
	return "RechargeTransaction [date=" + date + ", amount=" + amount + ", wallet=" + wallet + ", mobile=" + mobile
			+ "]";
}

}

