package com.cpg.Demoten.ui;

import java.math.BigDecimal;

import com.cpg.Demoten.dto.Emp;

public class Mytest {

	public static void main(String[] args)
	{
		
		
	Emp emp=new Emp(123,"radha", new BigDecimal(10000),0.1);
	System.out.println(emp.getEmpId());
		
System.out.println("Emp Id===="+emp.getEmpId());		
System.out.println("Emp Sallery====="+emp.takehomeSallery());
System.out.println("Emp Name======"+emp.getEmpName());
		Emp.pf=1200;
System.out.println("pf is"+emp.pf);

Emp empone=new Emp(1234,"abhi",new BigDecimal(12000),0.2);
System.out.println("Emp Id===="+empone.getEmpId());		
System.out.println("Emp Sallery====="+empone.takehomeSallery());
System.out.println("Emp Name======"+empone.getEmpName());
		
System.out.println("pf is"+emp.pf);

	
}
  
}
