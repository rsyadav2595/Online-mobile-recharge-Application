package com.cpg.Demoten.dto;

import java.math.BigDecimal;

public class Emp
{

public Emp(int empId, String empName, BigDecimal empSallery, double increment) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.pf = pf;   
		this.empSallery = empSallery;
		this.increment = increment;
	}

private int empId;
private String empName;
public static double pf;   ////////we create satic for pf so we give as public
private BigDecimal empSallery;
private double increment;

public Emp() {
	super();
	// TODO Auto-generated constructor stub
}

public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}



public BigDecimal getEmpSallery() {
	return empSallery;
}

public void setEmpSallery(BigDecimal empSallery) {
	this.empSallery = empSallery;
}

public double getIncrement() {
	return increment;
}

public void setIncrement(double increment) {
	this.increment = increment;
}

@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + ", pf=" + pf + ", empSallery=" + empSallery + ", increment="
			+ increment + "]";
}

public BigDecimal takehomeSallery()
{     
	BigDecimal in=BigDecimal.valueOf(this.increment);
	BigDecimal pfa=BigDecimal.valueOf(this.pf);
	BigDecimal takehomeSallery=this.empSallery.add(this.empSallery.multiply(in)).subtract(pfa);///use bigdecimal thats why we use add and sub 
	return takehomeSallery;
}


  public String getFullname()
  {
	  String CompanyName="CAPGEMINI";
	  return this.empName+CompanyName;
  }
}

