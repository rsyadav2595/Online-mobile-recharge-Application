package com.cg.jdbc.ui;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

public class Myapplication {

	public static void main(String[] args) 
	{
		
		// TODO Auto-generated method stub
       // create file in resource and add key and value
		String driver=null,,url=null,upass=null,unmae=null;
		try {
		InputStream it=new FileInputStream("src/main/resource /jdbc.properties");
   Properties prop=new Properties();
   prop.load(it);
   driver =prop.getProperty("jdbc.driver");
   url=prop.getProperty("jdbc.url")
   uname=prop.getProperty("jdbc.username");
   upass=prop.getProperty("jdbc.password");
   
   
   
		}catch(Filenot foubnd e1) {
			e1.printstacktrace;
			System.out.println("File not found");
		}catch(IOException e) {
			
			e.printStackTrace();
			System.out.println("Error file  not found");
		}
		finally
		{
			it.close();
		}
			
		}
		
		
		
		try { 
		Class.forname(com.mysql.jdbc.Driver);
	 DriverManager.getconnection("jdbc:mysql://localhost/db name" ,"root","password");
	 //PreparedStatement pstm=con.preparedstatment("INSERT INTO EMP VALUES(?,?,?)");
	 PreparedStatement pstm=con.preparedstatment("SELECT emp_id,emp_name,emp_salary FROM EMP");
	 ResultSet result=pstm.executeQuery();
	 
	 
	 
	     while(result.next()) {
		 int id=result.getInt("emp_id");
		 String name=result.getString("emp_name");
		 double salary=result.getDouble("emp_salary");
		 System.out.println(id+" "+name+" "+salary);
	 }
	 
	  //////for adding data into dabase 1 step done this and then comment it///
       //	 pstm.setInt(1, 1001);
      //	 pstm.setString(2,"abcd");   
     //	 pstm.setDouble(3, 1002.1);
    //	 
	 pstm.executeUpdate();
	 
	 
      System.out.println("connection done");
      }catch(Classcastexception e) {
	//try catch
       System.out.println("Driver not loaded");
	}catch(Sqlexception e)
	
	{
		System.out.println("connection not happen");
	}

}
