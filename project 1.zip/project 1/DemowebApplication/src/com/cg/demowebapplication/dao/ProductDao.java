package com.cg.demowebapplication.dao;

import java.util.List;

import com.cg.demowebapplication.dto.Product;

public interface ProductDao {
  
	
	
	public void save(Product prod) ;
	public List<Product> Showall();
	public Product findproduct(int id);
	public Product remove(int id);
	
}
