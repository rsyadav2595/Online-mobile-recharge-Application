package com.cg.demowebapplication.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapplication.dto.Product;

public class ProductDaoImpl  implements ProductDao{

	
	
	List<Product> mylist=new LinkedList<Product>();
	@Override
	public void save(Product prod) {
		// TODO Auto-generated method stub
		
		mylist.add(prod);
		
		
	}

	@Override
	public List<Product> Showall() {
		// TODO Auto-generated method stub
		return mylist;
	}

	@Override
	public Product findproduct(int id) {
		
    for (Product product : mylist) {
		if(product.getId()==id)
		{
			return product;
		}
	}
	return null;
		
	
		
	}

	@Override
	public Product remove(int id) {

   if(findproduct(id)!=null)
		
	mylist.remove(findproduct(id));	
	//return null;
return null;
	}

	
}
