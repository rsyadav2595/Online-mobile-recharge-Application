package com.cg.demowebapplication.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapplication.dto.Product;
import com.cg.demowebapplication.service.ProductServiceImpl;
import com.cg.demowebapplication.service.Productservice;

/**
 * Servlet implementation class productcontroller
 */



@WebServlet(urlPatterns= {"/add","/show","/search","/delete","/deleteproduct","/addproduct"})   //jsp page
//@WebServlet("/addproduct") html page
public class productcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /*
     * @see HttpServlet#HttpServlet()
     */
	
	Productservice service;
    public productcontroller() {
        super();
        
        service=new ProductServiceImpl();
      
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	
	//System.out.println("check-----");
	
	
	   doPost(request, response);
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  //doGet(request, response);
		  String url=request.getServletPath();

		   if(url.equals("/add")) {
			//AddProduct.jsp
			RequestDispatcher req=request.getRequestDispatcher("AddProduct.jsp");
			req.forward(request, response);
		}
		  if(url.equals("/show")) {
			//ShowProduct.jsp
        List<Product>mylist=service.ShowProduct();
        request.setAttribute("myproduct", mylist);
			RequestDispatcher req=request.getRequestDispatcher("ShowProduct.jsp");
			req.forward(request, response);
		}
		
		  if(url.equals("/search")) {
			//search product
			String ProductId=request.getParameter("productid");
			  Product prod=new Product();
			  int id= Integer.parseInt(ProductId);
			  prod=service.SearchProduct(id);
			  request.setAttribute("myproduct", prod);
		        
				RequestDispatcher req=request.getRequestDispatcher("SearchProduct.jsp");
				req.forward(request, response);	
			
		}
		  
		  if(url.equals("/delete"))
		  {
			  RequestDispatcher req=request.getRequestDispatcher("Delete.jsp");
				req.forward(request, response);	
		  }
		  
		  
		  if(url.equals("/deleteproduct"))
		  {
			  int id= Integer.parseInt(request.getParameter("productid"));
			  service.DeleteProduct(id);
			  response.getWriter().println("record delete");
			  
			  
				
		  }
		
		
		
		
		if(url.equals("/addproduct")) {
			//fetch data from addproduct.jsp
		
		
			
			
	String productid = request.getParameter("productid");
	String productname = request.getParameter("productname");
	String productprice = request.getParameter("productprice");
	String productonline = request.getParameter("productonline");
	String productcategory = request.getParameter("cato");

	
	System.out.println(productid);
	System.out.println(productname);
	System.out.println(productprice);
	System.out.println(productonline);
	System.out.println(productcategory);
	
	Product prod=new Product();
	prod.setId(Integer.parseInt(productid));
	prod.setName(productname);
	prod.setPrice(Double.parseDouble(productprice));
	prod.setOnline(productonline); 
	prod.setCategory(productcategory);
	
	
	
	service.addproduct(prod);
	//request.setAttribute("MyProduct", prod.getName());
	RequestDispatcher res=request.getRequestDispatcher("Productlist.jsp");
	
	//request.setAttribute("MyProduct", prod);
	
	
	res.forward(request, response);
	
	                       
//	PrintWriter out=response.getWriter();
//	
//	//out.println("<html><head> my output  </head><body>");
//	out.println("  Product id is=   "    +productid);         
//	out.println("  Product name is="   +productname);
//	out.println("  Product price is="   +productprice);
//	out.println("  Product online is="   +productonline);
//	out.println("  Product category is="  +productcategory);
//	//out.println("</body></html>");
	}

}
}
