package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dto.Product;

public interface Productservice {

	
	
	public void addproduct(Product prod);
	public List<Product> ShowProduct();
    public Product  SearchProduct(int id);
    public Product DeleteProduct(int id);
    public void UpdateProduct();
}
