package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dao.ProductDao;
import com.cg.demowebapplication.dao.ProductDaoImpl;
import com.cg.demowebapplication.dto.Product;

public class ProductServiceImpl implements Productservice {

	
	ProductDao dao;
	
	
	
	public ProductServiceImpl()
	{
		dao=new ProductDaoImpl();
	}
	
	@Override
	public void addproduct(Product prod) {
		// TODO Auto-generated method stub
		dao.save(prod);
	}

	@Override
	public List<Product> ShowProduct() {
		// TODO Auto-generated method stub
		return dao.Showall();
	}


	

	@Override
	public void UpdateProduct() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Product SearchProduct(int id) {
		// TODO Auto-generated method stub
		return dao.findproduct(id);
	}

	@Override
	public Product DeleteProduct(int id) {
		// TODO Auto-generated method stub
		return dao.remove(id);
	}

}
