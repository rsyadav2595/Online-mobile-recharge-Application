package com.cg.JPAOnlineMobileRecharge.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DbUtil {

	static EntityManager em=null;
	
	public  static EntityManager getConnection()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("OnlineMobileRecharge");
		em= emf.createEntityManager();
	    return em;
	}
	
	
	
	
	
	
}
