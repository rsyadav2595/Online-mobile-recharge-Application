package com.cg.JPAOnlineMobileRecharge.dto;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Wallet {
	

	
	public Wallet(double balance, BigInteger walletId, Customer customer, List<RechargeTransaction> transaction) {
		super();
		this.balance = balance;
		this.walletId = walletId;
		this.customer = customer;
		this.transaction = transaction;
	}


	@Column(name="balance")
	private double balance;
	
	
	@Id
	private BigInteger walletId;
	

	    @OneToOne
        @JoinColumn(name="customer_emailid")
	    private Customer customer;
	    
	    @OneToMany
	    @JoinColumn(name="walletId")
	   private List<RechargeTransaction> transaction; 
	 

	
	public Wallet()
	{
		super();

	}
	
		public double getBalance() {
		return balance;
	}







	public void setBalance(double balance) {
		this.balance = balance;
	}







	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<RechargeTransaction> getTransaction() {
		return transaction;
	}
	public void setTransaction(List<RechargeTransaction> transaction) {
		this.transaction = transaction;
	}

	public BigInteger getWalletId() {
		return walletId;
	}

	public void setWalletId(BigInteger walletId) {
		this.walletId = walletId;
	}


	@Override
	public String toString() {
		return "Wallet [balance=" + balance + ", walletId=" + walletId + ", customer=" + customer + ", transaction="
				+ transaction + "]";
	}	
}
