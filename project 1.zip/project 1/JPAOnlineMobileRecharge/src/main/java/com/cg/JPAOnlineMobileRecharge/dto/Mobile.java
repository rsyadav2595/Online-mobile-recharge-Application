package com.cg.JPAOnlineMobileRecharge.dto;

import java.math.BigInteger;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;




@Entity


public class Mobile {

	public Mobile(BigInteger mobileno, String operator) 
	{
		super();
		this.mobileno = mobileno;
		this.operator = operator;
		
	}



	@Id
	@Column(name="mobileno")
	private  BigInteger mobileno;
	
	@Column(name="operator")
	private String operator;
	
	
	public Mobile()
	{
		super();

	}
	

	
	public BigInteger getMobileno() 
	{
		return mobileno;
	}
	public void setMobileno(BigInteger mobileno) 
	{
		this.mobileno = mobileno;
	}
	public String getOperator() 
	{
		return operator;
	}
	public void setOperator(String operator)
	{
		this.operator = operator;
	}
	
	@Override
	public String toString() {
		return "Mobile [mobileno=" + mobileno + ", operator=" + operator + ",  ]";
	}
	
	
}
