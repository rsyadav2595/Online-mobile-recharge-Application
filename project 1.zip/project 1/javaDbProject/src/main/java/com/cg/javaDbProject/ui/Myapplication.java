package com.cg.javaDbProject.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Myapplication {

	public static void main(String[] args) {
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/emp","root","Capgemini123");
			 //DriverManager.getConnection("jdbc:mysql://localhost:3306/emp" ,"root","Capgemini123");
			 PreparedStatement pstm=con. prepareStatement("INSERT INTO data VALUES(?,?,?)");
			       pstm.setInt(1, 1001);
		      	   pstm.setString(2,"abcd");   
		           pstm.setDouble(3, 1002.1);
			//PreparedStatement pstm=conn.preparedstatment("SELECT emp_id,emp_name,emp_salary FROM EMP");
			       ResultSet result=pstm.executeQuery();
			 
			 
			 
			     while(result.next()) 
			     {
				 int id=result.getInt("123");
				 String name=result.getString("radhika");
				 double salary=result.getDouble("1234.6");
				 System.out.println(id+" "+name+" "+salary);
			     } 
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println("Driver not loaded");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		}
	}


