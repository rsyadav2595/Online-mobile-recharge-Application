package com.cpg.Interface.ui;

public class D  implements A,B{

	@Override
	public void setdata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getdata() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printdata() {
		// TODO Auto-generated method stub
		
	}

	
		
	}


