package com.cpg.Interface.ui;

public class Mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Timing temp=new dayshift();
		System.out.println(temp.time);
		temp.getlogin();
		temp.getlogout();
		temp.getcompany();
		
		
		
	}

}
