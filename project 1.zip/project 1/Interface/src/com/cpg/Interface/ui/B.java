package com.cpg.Interface.ui;

public interface B 
{
public void setdata();
}
