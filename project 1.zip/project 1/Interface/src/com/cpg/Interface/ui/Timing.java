package com.cpg.Interface.ui;

public interface Timing {

	double time=9.5;    ///static and final
	public void getlogin();
	public void getlogout();
	public void getcompany();


}
