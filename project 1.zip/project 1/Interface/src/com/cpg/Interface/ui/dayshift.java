package com.cpg.Interface.ui;

public class dayshift implements Timing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void getlogin() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getlogout() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getcompany() {
		// TODO Auto-generated method stub
		
	}

}
