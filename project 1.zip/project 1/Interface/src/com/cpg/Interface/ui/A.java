package com.cpg.Interface.ui;

public interface A {
public void  getdata();
public void printdata();
public void setdata();   ///    method is reapet in b i/f but it will override only one time
}
