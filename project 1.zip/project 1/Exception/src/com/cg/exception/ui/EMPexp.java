package com.cg.exception.ui;

public class EMPexp  extends RuntimeException      ///////user defined exp
{
    public EMPexp()
    {
	super();
     }
	public EMPexp(String msg)
	{
	super(msg)	;
	}
}
