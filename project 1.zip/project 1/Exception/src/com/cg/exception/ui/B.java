package com.cg.exception.ui;
import java.io.IOException;
public class B {

	public void getAll(int sal)  {
	
		
		
		if (sal<5000) {
		 throw new EMPexp("salary is greater than 5000");
	 }
		System.out.println(sal);

//		int a[] = {1,2,3}	;
//		try {
//			System.out.println(a[1]);
//		}
//    catch(Exception e) 
//         {
//			System.out.println("check array");
//		}
//		finally 
//		{
//			System.out.println("always-----");
//		}
//	    System.out.println("in B");
//	}

		
//	int a=10;
//	int b=0;
//	int c[]= {1,2,3};
//	try {
//		System.out.println(a/b);
//		System.out.println(c[9]);
//	} catch(ArithmeticException e) {
//		System.out.println("check 2nd no");
//	}catch(ArrayIndexOutOfBoundsException e) {
//		System.out.println("check array");
//	}finally {
//		System.out.println("always");
//	}
//		System.out.println("hiii");

//	int a=10;
//	int b=0;
//	if(b==0
//			
//			)
//	{
//		throw new ArithmeticException("b should be greater");
//	}
//	    System.out.println("result"+a/b);
//	
	
	
	
	
	}
}
                                             
                  