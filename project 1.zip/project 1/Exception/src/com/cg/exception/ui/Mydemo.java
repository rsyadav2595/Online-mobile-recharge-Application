package com.cg.exception.ui;



public class Mydemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
//		try {
//		FileReader it =new FileReader("abc.txt");
//		
//		it.read();
//	} catch ( IOException e)
//	{
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}                                             ////////checked exception
//			
		
	//	2nd
//		try {
//			Class.forName("");
//		} catch (ClassNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	try 
	{
	B b=new B();
	b.getAll(2000);
   
    }catch(EMPexp e) {
    	System.out.println(e.getMessage());
    }
	
}
}