package com.cg.Demotest.dto;

public class Calculator {
public double addNumber(double numOne,double numTwo)
{
	return numOne+numTwo;
}

public double subNumber(double numOne,double numTwo)
{
	return numOne-numTwo;
}


public double mulNumber(double numOne,double numTwo)
{
	return numOne*numTwo;
}

public double divNumber(double numOne,double numTwo)
{
	return numOne/numTwo;
}




}


