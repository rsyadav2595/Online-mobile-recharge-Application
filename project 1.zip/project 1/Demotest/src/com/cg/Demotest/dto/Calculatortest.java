package com.cg.Demotest.dto;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.After;
import org.junit.Before;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class Calculatortest {
//    int a;
    Calculator cal;
//    @BeforeAll
//    public static void beforeall()
//    {
//    	System.out.println("Before all=====");
//    }
//    
//    
    
	  @BeforeEach            ///////////1
	  public void dobeforeMyTEST()
      {
		  cal=new Calculator();
		  // assertEquals(12.0, cal.addNumber(10, 2));
//		a=10;
//		System.out.println("before test");	
      
      
      }
	  
	  
	
	
	  
	 @Test
	 
     public void doMYtest()
      {
		 assertEquals(12.0, cal.addNumber(10, 2));
       }
	

	 
	 @Test
     public void doMYtesttwo()
      {
		 assertEquals(8.0, cal.subNumber(10, 2));
       }
	 
	 
	 
	 @Test
     public void doMYtestthree()
      {
		 assertEquals(20.0, cal.mulNumber(10, 2));
       }
	 
	 @Test
     public void doMYtestfour()
      {
		 assertEquals(5.0, cal.divNumber(10, 2));
       }
	 
	 
	 @AfterEach
	public void doAftertest() 
	{
	cal=null;
	}
	 
	 

//  @AfterAll
//  public  static void afterall()
//   {
//	System.out.println("After all======");
//   }



}




