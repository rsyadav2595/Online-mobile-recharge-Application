package com.cg.JPADemo.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.JPADemo.dto.Employee;
import com.cg.JPADemo.util.Dbutil;

public class EmployeeDaoImpl  implements EmployeeDao{

	EntityManager em ;
	
	public EmployeeDaoImpl ()
	{
		em=Dbutil.getConnection();
	}
	
	
	public void save(Employee emp) 
	{
		
		em.persist(emp);
		em.getTransaction().commit();
	}

	public List<Employee> findBySalary(Double low, Double higher) 
	{
		// TODO Auto-generated method stub
		//////JPQL//////
		Query query =em.createQuery("FROM Employee WHERE salary BETWEEN  :below AND :high");
		query.setParameter("below", low);
		query.setParameter("high", higher);
		List<Employee> emplist=query.getResultList();
		
		
		return emplist;
	}

	public List<Employee> findBydeptName(String name) 
	{
		
		return null;
	}

}
