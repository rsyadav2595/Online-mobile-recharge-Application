package com.cg.JPADemo.Dao;

import java.util.List;

import com.cg.JPADemo.dto.Employee;

public interface EmployeeDao {
	public void save(Employee emp);
	public List<Employee> findBySalary(Double low,Double higher);
	public List<Employee> findBydeptName(String name);

}
