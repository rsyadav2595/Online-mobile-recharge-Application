package com.cg.JPADemo.service;

import java.util.List;

import com.cg.JPADemo.dto.Employee;

public interface EmployeeService {


public void addEmployee(Employee emp);
public List<Employee> searchBySalary(Double low,Double higher);
public List<Employee> searchBydeptName(String name);


}
