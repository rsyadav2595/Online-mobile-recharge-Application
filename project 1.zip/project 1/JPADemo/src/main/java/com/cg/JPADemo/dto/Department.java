package com.cg.JPADemo.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Department {
	
public Department(int id, String name, List<Employee> myEmployeelist) {
		super();
		this.id = id;
		this.name = name;
		this.myEmployeelist = myEmployeelist;
	}
public Department() {
		super();
		// TODO Auto-generated constructor stub
	}
public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

@Id
@Column(name="dept_id")
private int id;
@Column(name="dept_name")
private String name;
@OneToMany(mappedBy="dep",cascade=CascadeType.ALL)
         

// @OneToMany
        private List<Employee> myEmployeelist=new ArrayList<Employee>();    ////for one to many

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}


public List<Employee> getMyEmployeelist() {
	return myEmployeelist;
}
public void setMyEmployeelist(List<Employee> myEmployeelist) {
	this.myEmployeelist = myEmployeelist;
}
@Override
public String toString() {
	return "Department [id=" + id + ", name=" + name + ", myEmployeelist=" + myEmployeelist + "]";
}

}
