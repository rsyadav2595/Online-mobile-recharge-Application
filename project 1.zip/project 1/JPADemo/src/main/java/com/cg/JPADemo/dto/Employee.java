package com.cg.JPADemo.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
///one primary key contains atleast when we use entity
  @Entity
  @Table                       
  public class Employee {

	

	public Employee(int id, String name, Double salary, boolean type, Address addr, Department dep,
			Date dateofJoining) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.type = type;
		this.addr = addr;
		this.dep = dep;
		this.dateofJoining = dateofJoining;
	}
	@Id   
	@Column(name="emp_id")
	private int id;
	@Column(name="emp_name")
	 private String name;
	@Column(name="emp_salary")
	 private Double salary;
	@Column(name="emp_type")
	 private boolean type;
	@Column(name="joining")
	//@Temporal(TemporalType.TIME)
	
	@Embedded
	private Address addr;
	
	//@OneToMany(mappedBy="dep",cascade=CascadeType.ALL)
    


       //	 @OneToOne                                 /////for one to many remove it becoz we tale list in emp class
       //     private Department dep;
        //	

////bidirectional///
    	
	@ManyToOne(cascade=CascadeType.ALL)                           /////for one to many remove it becoz we tale list in emp class
         private Department dep;
    @JoinColumn(name="dep")	
    	

	 
	 @Temporal(TemporalType.DATE)    ///only dae is added  when we not write then date and time both prints
	 private Date dateofJoining;      ///for adding only time use datatype timestamp 
	
	 public Employee() 
	    {
			super();
			// TODO Auto-generated constructor stub
		}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public boolean isType() {
		return type;
	}
	public void setType(boolean type) {
		this.type = type;
	}


	public Date getDateofJoining() {
		return dateofJoining;
	}

	public void setDateofJoining(Date dateofJoining) {
		this.dateofJoining = dateofJoining;
	}

	
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type + ", addr=" + addr
				+ ", dep=" + dep + ", dateofJoining=" + dateofJoining + "]";
	}
	public Department getDep() {
		return dep;
	}
	public void setDep(Department dep) {
		this.dep = dep;
	}
	





}

