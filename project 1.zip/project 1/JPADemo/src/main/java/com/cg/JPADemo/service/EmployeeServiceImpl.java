package com.cg.JPADemo.service;

import java.util.List;

import com.cg.JPADemo.Dao.EmployeeDao;
import com.cg.JPADemo.Dao.EmployeeDaoImpl;
import com.cg.JPADemo.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDao dao;
	
	
	
	
	public EmployeeServiceImpl()
	{
		dao=new EmployeeDaoImpl();
	}
	
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		dao.save(emp);
	}

	public List<Employee> searchBySalary(Double low, Double higher) {
		// TODO Auto-generated method stub
		return dao.findBySalary(low, higher);
	}

	public List<Employee> searchBydeptName(String name) {
		// TODO Auto-generated method stub
		return dao.findBydeptName(name);
	}

}
