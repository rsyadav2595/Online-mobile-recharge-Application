package com.cg.JPADemo.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.cg.JPADemo.dto.Address;
import com.cg.JPADemo.dto.Department;
import com.cg.JPADemo.dto.Employee;
import com.cg.JPADemo.service.EmployeeService;
import com.cg.JPADemo.service.EmployeeServiceImpl;

public class Employeeapplication {
	static EmployeeService service ;
	

	public static void main(String[] args) {
			
		service =new EmployeeServiceImpl();
		
  Scanner scr=new Scanner(System.in);
  System.out.println("Enter emp id");
  int id=scr.nextInt();
  System.out.println("enter name");
  String name=scr.next();
  System.out.println("Enter sallary");
  Double sallary=scr.nextDouble();
  System.out.println("date of joining");
  String date=scr.next();
  System.out.println("Enter dept id");
  int did=scr.nextInt();
  System.out.println("Enter dept name");
  String dname=scr.next();
  
		
 
  
  
		
		Department dep=new Department();
		dep.setId(did);
		dep.setName(dname);
		
		Employee emp=new Employee();
		emp.setId(id); 
		emp.setName(name);
		emp.setSalary(sallary);
		emp.setAddr(new Address());
		emp.setDateofJoining(new Date());
		emp.setDep(dep);
				
		
		service.addEmployee(emp);
		List<Employee> mylist =service.searchBySalary(1000.0, 3000.89);
		for (Employee employee : mylist)
		{
			System.out.println("Emp id=="  +employee.getId());
			System.out.println("Emp name=="  +employee.getName());
			System.out.println("Emp sallery== " +employee.getSalary());
			System.out.println("Emp Dept=="  +employee.getDep().getName());
		}
	   
		
		
		
		
		
		
		
//// ////without layerd architecture///////
//	EntityManagerFactory emf=Persistence.createEntityManagerFactory("Demoemployeemanagment");
//	EntityManager em= emf.createEntityManager();
//	EntityTransaction tx=em.getTransaction();
//	
//	
//	  //Employee emp= new Employee(101,"dvf",6546.55,true,new Date(),addr);        ///add emp,with dateand time
//		//Employee emp = em.find( Employee.class, 123 );                    ///find
//		//em.remove(emp);                                            //remove
//	    // emp.setSalary(2345.8);                            //set
//	    tx.begin();
//        Address addr=new Address();
//        
//            addr.setCity("maharashtra");
//            addr.setPincode(1234);
//            addr.setState("pune");
//        
//      
//        
//        
//        
//        Department dep=new Department();      //for manyto one
//        		dep.setId(500);
//                dep.setName("CSE");
//                
//                
//                Department depTwo=new Department();
//                depTwo.setId(600);
//                depTwo.setName("MECH");
//        
//        
//        Employee emp=new Employee();
//        
//               emp.setId(1);
//               emp.setName("ABC");
//               emp.setSalary(1234.7);
//               emp.setType(true);
//               emp.setDateofJoining(new Date());
//               emp.setAddr(addr);
//               emp.setDep(dep);
//              
//               Employee emptwo=new Employee();     ////foe one to many
//               emptwo.setId(2);  
//               emptwo.setName("PQRS");
//               emptwo.setSalary(23345.7);
//               emptwo.setDateofJoining(new Date());
//               emptwo.setType(true);
//               emptwo.setAddr(addr);
//               emptwo.setDep(depTwo);
//        
//               
//               Employee empthree=new Employee();      ///foe one to many
//               empthree.setId(3);
//               empthree.setName("ankita");
//               empthree.setSalary(23345.7);
//               empthree.setDateofJoining(new Date());
//               empthree.setType(true);
//               empthree.setAddr(addr);
//               empthree.setDep(depTwo);
//               
////               ///1st way////
////              List<Employee> mylist=new ArrayList<Employee>();
////              mylist.add(emp);
////              mylist.add (emptwo);
////              mylist.add( empthree);
////              
//             //   dep.setMyEmployeelist(mylist);
//               
//             ///OR 2 nd way////
////               
////               dep.getMyEmployeelist().add(emp);    
////               dep.getMyEmployeelist().add( emptwo);     
////               dep.getMyEmployeelist().add( empthree);
////               
//       
//               
//               
//               
//               
//           // em.persist(dep);   //manage data
//     //  em.persist(depTwo);
//        em.persist(emp);
//        em.persist(emptwo);              
//        em.persist(empthree);
//        tx.commit();  //save data
//		
	}
	
	}	
	
