package com.cg.JPADemo.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Dbutil {
	
	static EntityManager em=null;
	public  static EntityManager getConnection()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Demoemployeemanagment");
		em= emf.createEntityManager();
		em.getTransaction().begin();
		
		return em;
		
	
	
	
	
	}
	

	
	
	
	
}
