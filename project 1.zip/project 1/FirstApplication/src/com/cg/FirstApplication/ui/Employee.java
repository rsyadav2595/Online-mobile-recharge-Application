package com.cg.FirstApplication.ui;

public class Employee {

	public Employee(int empId, String empName, double empSallery, String empDeg, Product product) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSallery = empSallery;
		this.empDeg = empDeg;
		this.product = product;
	}
	
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int empId;
	  private String empName;
	  private double empSallery;
	  private String empDeg;
	  private Product product;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId)
	{
		this.empId = empId;
	}
	public String getEmpName()
	{
		return empName;
	}
	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public double getEmpSallery() 
	{
		return empSallery;
	}
	public void setEmpSallery(double empSallery)
	{
		this.empSallery = empSallery;
	}
	public String getEmpDeg() 
	{
		return empDeg;
	}
	public void setEmpDeg(String empDeg) 
	{
		this.empDeg = empDeg;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product)
	{
		this.product = product;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSallery=" + empSallery + ", empDeg=" + empDeg
				+ ", product=" + product + "]";
	}
	
	
	
	
	
}
