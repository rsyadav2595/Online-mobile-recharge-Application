package com.cg.FirstApplication.ui;

public class Product {

	public Product(int productId, String productname, Double productcost, String productDes) {
		super();
		this.productId = productId;
		this.productname = productname;
		this.productcost = productcost;
		this.productDes = productDes;
	}
	public Product() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int productId;
	 private String productname;
	 private Double productcost;
	 private String productDes;
	public int getProductId() 
	{
		return productId;
	}
	public String getProductname()
	{
		return productname;
	}
	public void setProductname(String productname)
	{
		this.productname = productname;
	}
	public Double getProductcost()
	{
		return productcost;
	}
	public void setProductcost(Double productcost)
	{
		this.productcost = productcost;
	}
	public String getProductDes()
	{
		return productDes;
	}
	public void setProductDes(String productDes)
	{
		this.productDes = productDes;
	}
	@Override
	public String toString() 
	{
		return "Product [productId=" + productId + ", productname=" + productname + ", productcost=" + productcost
				+ ", productDes=" + productDes + "]";
	}
}
