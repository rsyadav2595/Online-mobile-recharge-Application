package com.cg.FirstApplication.dto;

import com.cg.FirstApplication.ui.Employee;
import com.cg.FirstApplication.ui.Product;

public class ApplicationFirst 
{

	public static void main(String[] args)
	{
		
	Employee emp=new Employee();
	Product prd=new Product();
	
  //Scanner scr=new Scanner(System.in);
	//System.out.println("Enter emp id");
	//int id=scr.nextInt();
	//System.out.println("Enter emp name");
	//String name=scr.next();
	//System.out.println("Enter sallery");
	//Double sal= scr.nextDouble();
	//System.out.println("Enter deg");
//	String deg=scr.next();
	
	//emp.setEmpId(id);
//	emp.setEmpName(name);
	//emp.setEmpSallery(sal);
	//emp.setEmpDeg(deg);
	//emp.setProduct(prd);
	}	
	     public void  processOption(char option)
	    {
		   switch(option)
		   {
		        case '1':
		           AddEmployee();
		          break;
		      
		        case '2':
		           showEmployee();
		           break;
		        case '3':
		             Exit();
		           break;
		   }	
		   
}
	
	
	public  void Exit() {
		// TODO Auto-generated method stub
		
	}
	public void showEmployee() {
		// TODO Auto-generated method stub
		
		
	}
	public void AddEmployee() {
		// TODO Auto-generated method stub
		System.out.println("Enter the employee id:");
		System.out.println("Enter the employee name:");
		System.out.println("Enter the employee sallery:");
		System.out.println("Enter the employee deg:");

	}

}


