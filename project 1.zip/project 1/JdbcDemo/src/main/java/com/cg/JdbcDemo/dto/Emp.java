package com.cg.JdbcDemo.dto;

public class Emp {



	public Emp(int id, String name, double sallery) {
		super();
		this.id = id;
		this.name = name;
		this.sallery = sallery;
	}
	public Emp() {
		super();
		// TODO Auto-generated constructor stub
	}
	private int id;
	private String name;
	private double sallery;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSallery() {
		return sallery;
	}
	public void setSallery(double sallery) {
		this.sallery = sallery;
	}
	@Override
	public String toString() {
		return "Emp [id=" + id + ", name=" + name + ", sallery=" + sallery + "]";
	}
	
	
}