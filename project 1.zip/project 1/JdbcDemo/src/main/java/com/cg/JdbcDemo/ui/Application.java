package com.cg.JdbcDemo.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.JdbcDemo.dto.Emp;
import com.cg.JdbcDemo.exception.EmpException;
import com.cg.JdbcDemo.service.Empservice;
import com.cg.JdbcDemo.service.EmpserviceImpl;



public class Application {
	  static Empservice  service;
		public Application()
		{
			}
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			service=new EmpserviceImpl();
			int choice=0;
			do {
				printDetails();
				System.out.println("Enter the choice");
				choice=sc.nextInt();
				switch(choice)
				{
					 
				case 1: 
					System.out.println("Enter the Id");
					int id=sc.nextInt();
					System.out.println("Enter name");
					String name=sc.next();
					System.out.println("Enter sallery");
					double sallery=sc.nextDouble();
					
					Emp emp=new Emp();
					emp.setId(id);
					emp.setName(name);
					emp.setSallery(sallery);
					
					service.addEmployee(emp);
					break;
					
				case 2: 
						  List<Emp>mylist =service.showAll();
						   for(Emp empdata:mylist) {
							System.out.println("id is"+empdata.getId());
							System.out.println("name is"+empdata.getName());
							System.out.println("sallery is"+empdata.getSallery());				
						}
						   break;
						
				case 3:
					System.out.println("Enter the emp to search");
					String sname=sc.next();
					List<Emp> empsearch=service.searchByName(sname);
					for (Emp empAll : empsearch) {
						System.out.println("id is"+empAll.getId());
					}
					break;
					
				case 4:
					System.out.println("Enter emp id");
					int sid=sc.nextInt();
			
					
					try {
						Emp empSearch = service.searchById(sid);
						if(empSearch==null) {
							System.out.println("Enter sal");
							double salnew=sc.nextDouble();
				
							empSearch.setSallery(salnew);
					 service.update(empSearch);
					}
					}catch(EmpException e)
					{
						System.out.println(e.getMessage());
					}
					
					 
		            
					break;
					
	      }
			}while(choice!=6); {
				}		
	}private static void printDetails() {
			System.out.println("1.Add Emp");
			System.out.println("2.show emp");
			System.out.println("3.search by name");
			System.out.println("4.update Emp");
		}
		

	}


