package com.cg.JdbcDemo.service;

import java.util.List;

import com.cg.JdbcDemo.dao.EmpDao;
import com.cg.JdbcDemo.dao.EmpDaoImpl;
import com.cg.JdbcDemo.dto.Emp;

public class EmpserviceImpl implements Empservice {
	  EmpDao dao;
		public  EmpserviceImpl()
		{
			dao=new EmpDaoImpl();
		}
	public void addEmployee(Emp emp) {
		// TODO Auto-generated method stub
		emp.setSallery(emp.getSallery()+emp.getSallery()*0.1);   /////for increasing sal//
		dao.save(emp);
			}
	

	public List<Emp> searchByName(String name) {
		// TODO Auto-generated method stub
		return dao.findBy(name);
	}

	public Emp searchById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	public List<Emp> showAll() {
		// TODO Auto-generated method stub
		return dao.showAll();
	}

	public Emp update(Emp emp) {
		// TODO Auto-generated method stub
		return null;
	}

	public void sort() {
		// TODO Auto-generated method stub
		
	}

}
