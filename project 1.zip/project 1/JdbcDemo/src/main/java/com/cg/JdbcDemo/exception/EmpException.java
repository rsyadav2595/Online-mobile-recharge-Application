package com.cg.JdbcDemo.exception;

public class EmpException extends RuntimeException{
	public EmpException()
	{
		
	}
	
	public EmpException(String msg)
	{
		super(msg);
	}

	
	
	
}
