package com.cg.JdbcDemo.dao;

import java.util.List;

import com.cg.JdbcDemo.dto.Emp;
import com.cg.JdbcDemo.exception.EmpException;


public interface EmpDao {
	public Emp save(Emp emp);
	public List<Emp>findBy(String name); 
	public Emp findById(int id);
	public List<Emp> showAll();

}
