package com.cg.JdbcDemo.service;

import java.util.List;

import com.cg.JdbcDemo.dto.Emp;
import com.cg.JdbcDemo.exception.EmpException;


public interface Empservice {
	
	
	public void addEmployee(Emp emp) ;
	public List<Emp>searchByName(String name);
	public Emp searchById(int id) throws EmpException;
	
	public List<Emp>showAll();
    public Emp update(  Emp emp);   ///id is uniq so return type is Emp
    public  void sort();


}
