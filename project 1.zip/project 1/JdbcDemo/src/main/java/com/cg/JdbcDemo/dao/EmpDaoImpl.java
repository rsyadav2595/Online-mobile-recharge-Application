package com.cg.JdbcDemo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.JdbcDemo.dto.Emp;
import com.cg.JdbcDemo.exception.EmpException;
import com.cg.JdbcDemo.util.Dbutil;

public class EmpDaoImpl implements EmpDao  {

	PreparedStatement pstm=null;
	List<Emp> empData;
	 public EmpDaoImpl()
	 {
		 empData=new ArrayList<Emp>();
	 }

	
	public Emp save(Emp emp) {
		
		
		Connection con=Dbutil.getConnection();
		
	        String query_insert="INSERT INTO employee VALUES(?,?,?) ";
			try{
			 PreparedStatement pstm=con.prepareStatement (query_insert);
		
			
			pstm.setInt(1, emp.getId());
			pstm.setString(2, emp.getName());
			pstm.setDouble(3, emp.getSallery());
		
			pstm.executeQuery();
		}catch(SQLException e) {
			
			e.printStackTrace();
		}
			finally
			{
			try {
				pstm.close();
				con.close();
			}catch(SQLException e){
				e.printStackTrace();
				throw new EmpException ("Connection not closed");
			}
			}
			return emp;
	}
		
		
		
	

	public List<Emp> findBy(String name) {
		List<Emp>empSearch=new ArrayList<Emp>();
		for (Emp emp : empData) {
			if (emp.getName().equals(name));
			empSearch.add(emp);
		}
		return empSearch;
	}

	public Emp findById(int id) {
		for (Emp emp : empData) {
			if(emp.getId()==id) {
				return emp;
			}else {
			 throw new EmpException("Id not found");
			}
		}
		return null;
	
	}


	public List<Emp> showAll() {
		 Connection con =Dbutil.getConnection();
    	 String Query_show="SELECT emp_id,emp_name,emp_salary FROM Emp";
    	 PreparedStatement pstm=null;
   	     List<Emp>mylist=new ArrayList<Emp>();
    	 try {
    		 
    		pstm=con.prepareStatement(Query_show) ;
    		 ResultSet result=pstm.executeQuery();
    	 
     
    	while(result.next())
    	{
    		Emp emp=new Emp();
   		emp.setId(result.getInt("emp_id"));
    		emp.setName(result.getString("emp_name"));
   		emp.setSallery(result.getDouble("emp_salary"));
    		mylist.add(emp);
    	}
    	}
    	 catch(SQLException e)
    	 {
    	 throw new EmpException("Show not found");
         }
     finally
     {
   	 try {
    		 pstm.close();
   		 con.close();
   	 }
   	 catch (SQLException e)
   	 {
   		e.printStackTrace();
   //	 return mylist;
    	
   	 }
	}
		return mylist;
	}
}
	
	
	

