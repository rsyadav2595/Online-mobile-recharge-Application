package com.cg.DemoOneSpring.ui;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.DemoOneSpring.config.JavaConfig;
import com.cg.DemoOneSpring.dao.ProductDaoImpl;
import com.cg.DemoOneSpring.dto.Product;
import com.cg.DemoOneSpring.dto.Transaction;
import com.cg.DemoOneSpring.service.ProductService;
import com.cg.DemoOneSpring.service.ProductServiceImpl;


@Component
public class Mytest {
	
	
	  @Autowired
	  ProductService productService;
	  static ProductService service;
	 
	 @PostConstruct
	 public void init()
	 {
		 service=this.productService;
	 }
	  static Product product;
	  public static void main(String[] args) {

		 ApplicationContext appContext = new AnnotationConfigApplicationContext(JavaConfig.class);
  
		 
		 
		  ProductDaoImpl impl =(ProductDaoImpl) appContext.getBean("productdao");

		 Product myproduct = (Product) appContext.getBean("prod");
	     Transaction mytran=	(Transaction)appContext.getBean("tran");
	
	     myproduct.setId(1001);
	
	 myproduct.setName("mobile");
	myproduct.setPrice(528.3);
	myproduct.setDescription("good");
	
	
	
	mytran.setId(12);
	mytran.setAmount(5486.3);
	mytran.setDescription("for product");
	
	
	
	
//	 myproduct.getAllData();
//	System.out.println(myproduct);
	//ProductService productservice=new ProductServiceImpl();
	
	service.addproduct(myproduct);
	
	System.out.println(service.showAllProduct());
	
	  
	  

	  
	  }

}
