package com.cg.DemoOneSpring.dto;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("prod")
public class Product {

	private int id;
	private String name;
	private Double price;
	private String Description;
	@Autowired // connection betw two classes
	private Transaction tran;

	public Product() {

		//System.out.println("product const");

	}

	/*public void getAllData() {
		System.out.println("Id is===" + id);
		System.out.println("name is==" + name);
		System.out.println("price is==" + price);
		System.out.println("Des is===" + Description);

		System.out.println("Id of tran is --" + tran.getId());
		System.out.println("amount of tran is --" + tran.getAmount());
		System.out.println("Des of tran is --" + tran.getDescription());

	}*/

	public Product(int id, String name, Double price, String description) {
		super();
		this.id = id;
		this.name = name;
		this.price = price;
		Description = description;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	public String getDescription() {
		return Description;
	}

	public void setDescription(String description) {
		Description = description;
	}

	public Transaction getTran() {
		return tran;
	}

	public void setTran(Transaction tran) {
		this.tran = tran;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", price=" + price + ", Description=" + Description + ", tran="
				+ tran + "]";
	}

}
