package com.cg.DemoOneSpring.dao;

import java.util.List;

import com.cg.DemoOneSpring.dto.Product;

public interface ProductDao {

	
	public void save(Product prod);
	public List<Product> showAllProduct();
}
