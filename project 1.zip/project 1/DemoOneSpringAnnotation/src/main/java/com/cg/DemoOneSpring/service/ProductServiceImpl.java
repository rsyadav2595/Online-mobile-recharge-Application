package com.cg.DemoOneSpring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.DemoOneSpring.dao.ProductDao;
import com.cg.DemoOneSpring.dto.Product;


@Service("productservice")
public class ProductServiceImpl  implements ProductService{

	@Autowired
	ProductDao productdao;
	
	public ProductServiceImpl()
	{
		
	}
	
	public void addproduct(Product prod) {
		// TODO Auto-generated method stub
		productdao.save(prod);
	}

	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return productdao.showAllProduct();
	}

}
