package com.cg.DemoOneSpring.service;

import java.util.List;

import com.cg.DemoOneSpring.dto.Product;

public interface ProductService {

	
	public void addproduct(Product prod);
	public List<Product> showAllProduct();
}
