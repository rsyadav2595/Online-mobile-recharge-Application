package com.cg.DemoOneSpring.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.DemoOneSpring.dto.Product;
import com.cg.DemoOneSpring.dto.Transaction;

@Configuration
@ComponentScan("com.cg.DemoOneSpring")
public class JavaConfig {

	
	
	
	
	
	
	
	
	// @Bean(name="prod",autowire=Autowire.BY_TYPE) //join two class by using this
	// autowire
	// public Product getProduct()
	// {
	//
	// Product pro=new Product();
	// pro.setId(2525);
	// pro.setName("abc");
	// pro.setPrice(52548.2);
	// pro.setDescription("goood");
	//
	// return pro;
	// }
	// @Bean(name="tran")
	// public Transaction gettransaction()
	// {
	//
	// Transaction t =new Transaction();
	// t.setId(12);
	// t.setAmount(1123.6);
	// t.setDescription("for product");
	// return t;
	//
	// }
	//

}
