package com.cg.DemoOneSpring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.DemoOneSpring.dto.Product;

@Repository("productdao")
public class ProductDaoImpl  implements ProductDao{

	List<Product>productlist=new ArrayList<Product>();
	
	public void save(Product prod) {
	
		productlist.add(prod);
	}

	public List<Product> showAllProduct() {
		
		return productlist;
	}

}
