package com.cg.springsampledemotwo.sevice;

import java.util.List;

import com.cg.springsampledemotwo.dto.Customer;

public interface CustomerService {

	
	List<Customer> FindAll();
}
