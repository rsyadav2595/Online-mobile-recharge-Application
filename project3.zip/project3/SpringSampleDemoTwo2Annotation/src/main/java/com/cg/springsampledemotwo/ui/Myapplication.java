package com.cg.springsampledemotwo.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.springsampledemotwo.sevice.CustomerService;
import com.cg.springsampledemotwo.sevice.CustomerServiceImpl;

public class Myapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


		ApplicationContext appContext=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		CustomerService service=appContext.getBean("service", CustomerService.class);
		System.out.println(service.FindAll().get(0).getFirstname());
		
		
	}

}
