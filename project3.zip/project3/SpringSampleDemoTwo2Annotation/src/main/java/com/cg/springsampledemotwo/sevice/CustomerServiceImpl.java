package com.cg.springsampledemotwo.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springsampledemotwo.dao.CustomerDao;
import com.cg.springsampledemotwo.dao.CustomerDaoImpl;
import com.cg.springsampledemotwo.dto.Customer;


@Service("service")
public class CustomerServiceImpl  implements CustomerService{

	
	//@Autowired
	private CustomerDao dao;

	
	@Autowired
    public CustomerServiceImpl(CustomerDao dao)
    {   
		
		System.out.println("using constructer injection");
    	this.dao=dao;
    }
	
    //@Autowired
	public void setDao(CustomerDao dao) {
		
    	System.out.println("in setter injection");
    	this.dao = dao;
	}

	public List<Customer> FindAll() {
		// TODO Auto-generated method stub
		return dao.FindAll();
	}
	
	
	

	
	
	
}
