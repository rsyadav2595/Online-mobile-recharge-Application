package com.cg.springsampledemotwo.dao;

import java.util.List;

import com.cg.springsampledemotwo.dto.Customer;

public interface CustomerDao {
     
	
	public  List<Customer> FindAll();	
}
