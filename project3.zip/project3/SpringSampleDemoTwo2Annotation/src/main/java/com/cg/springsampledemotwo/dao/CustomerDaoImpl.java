package com.cg.springsampledemotwo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springsampledemotwo.dto.Customer;


@Repository("dao")
public class CustomerDaoImpl implements CustomerDao {

	public List<Customer> FindAll() {
		
		List<Customer> customers=new ArrayList<Customer>();
		
		Customer customer =new Customer();
		
		customer.setFirstname("Radhika");
		customer.setLastname("yadav");
		customers.add(customer);
		
		return customers;
	}

}
