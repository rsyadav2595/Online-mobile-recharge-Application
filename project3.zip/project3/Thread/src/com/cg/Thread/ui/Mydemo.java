package com.cg.Thread.ui;

//public class Mydemo  implements Runnable{
//
//	@Override
//	public void run() {
//	System.out.println("Hello from thread 1");
//		
//	}
//
//	public static void main(String[] args) {
//		Mydemo demo=new Mydemo();
//		Thread th=new Thread();
//		(new Thread(new Mydemo())).start();
//	}
//}

///////implements runnable//////




public class  Mydemo extends Thread {

    public void run() {
        System.out.println("Hello from a thread!");
    }

    public static void main(String args[]) {
      Mydemo demo=new Mydemo();
    //	(new Mydemo()).start();
   demo.start();
   
    
    }

}

/////extending thread/////



