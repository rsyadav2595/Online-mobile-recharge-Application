package com.cg.springsampledemotwo.sevice;

import java.util.List;

import com.cg.springsampledemotwo.dao.CustomerDao;
import com.cg.springsampledemotwo.dao.CustomerDaoImpl;
import com.cg.springsampledemotwo.dto.Customer;

public class CustomerServiceImpl implements CustomerService {

	  private  CustomerDao dao;
	
	
	public CustomerDao getDao() {
		return dao;
	}


	public void setDao(CustomerDao dao) {
		this.dao = dao;
	}


	public CustomerServiceImpl()
	{
		
	}
	
	
	public CustomerServiceImpl(CustomerDao customerdao)   ///constructor injection
	{
		this.dao=dao;
	}
	
	public List<Customer> FindAll() {

		return dao.FindAll();
	}

//	public void setDao(CustomerDao dao) /// setter injection
//	{
//		this.dao = dao;
//	}

	

}
	