package com.cg.Tokenizer.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class Demotoken {

	public static void main(String[] args) {

           Reader fileRead=null;
           Writer filewrite=null;
           BufferedReader bufreader=null;
           BufferedWriter bufwriter=null;
           
           try {
			fileRead =new FileReader("read.txt");
			bufreader =new  BufferedReader(fileRead);
			filewrite=new FileWriter("write.txt");
			bufwriter =new  BufferedWriter (filewrite);
			String data=null;
			String token=null;
			while((data=bufreader.readLine())!=null);
			  
			{
				StringTokenizer st=new StringTokenizer(data, ", ");
				System.out.println("st");
				while(st.hasMoreTokens())
				{
					token=st.nextToken();
				}
		
			System.out.println(token);
			 filewrite.write(data);
           
			}	
			
			
		} catch (FileNotFoundException e)
           {
			System.out.println("file not found");
		   }
           
           catch (IOException e)
           {
           }finally
			{
				try {
					fileRead.close();
					filewrite.close();
					}
				 catch (IOException e) {
					 System.out.println("file not found");
				 }
			
			
			}
		
		
	}

}
