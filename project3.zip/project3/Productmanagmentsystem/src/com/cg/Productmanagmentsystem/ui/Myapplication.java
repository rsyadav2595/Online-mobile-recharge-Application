package com.cg.Productmanagmentsystem.ui;

import java.util.Scanner;

import com.cg.Projectmanagmentsystem.dto.Product;
import com.cg.Projectmanagmentsystem.service.IProductservice;
import com.cg.Projectmanagmentsystem.service.ProductService;

public class Myapplication {

	public static void main(String[] args) {
		
		
		printDetails();
		Product pro=new Product(); 
		IProductservice service=new ProductService();
		
		Scanner scr=new Scanner(System.in);
		int choice=0;
		do {
		 System.out.println("Enter the choice......");
		choice= scr.nextInt();
		 switch(choice)
		 {
		 case 1:  //add
			 
		 // System.out.println("in add");	 
		  System.out.println("Enter the id");
			 int id=scr.nextInt();
			 System.out.println("Enter the product name");
			 String name=scr.next();
	           System.out.println("Enter price");
	           double price=scr.nextDouble();
	           System.out.println("enter description");
	           String des=scr.next();
	           pro.setId(id);
	           pro.setName(name);
	           pro.setPrice(price);
	           pro.setDescription(des);
	           service.addProduct(pro);
			 break;
		 case 2:  //show
			 Product[] allData=service.showAllProduct();
			 for(Product product:allData)
			 {
				  System.out.println("product ID id"+product.getId());
				  System.out.println("Product Name is"+product.getName());
				  System.out.println("product Price is"+product.getPrice());
				  System.out.println("product description is"+product.getDescription());	 
					 
					 
					 
		 }
			  System.out.println("in show");	 
			 
			 break;
			 
			
		 
		     case 3:   //exit
			 break;
			 
        }
			
			}while(choice!=0);
		
	}

	
 public static void	printDetails()
{
	System.out.println("--------------");
	System.out.println("1. Add product");
	System.out.println("2.show all product");
	System.out.println("3.exit");
}
	
	
}



