package com.cg.Productmanagmentsystem.dao;

import com.cg.Projectmanagmentsystem.dto.Product;

public interface IproductDao {
  
	
	public Product addproduct(Product pro);
	public Product[] showAll();
	
}
