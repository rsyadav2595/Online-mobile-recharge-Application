package com.cg.Productmanagmentsystem.dao;

import com.cg.Projectmanagmentsystem.dto.Product;

public class ProductDao implements IproductDao  {

	
	Product prod[];       ///object of product of array type
	int i=0;
	public ProductDao()                ////constructor
	{
		prod =new Product[2];
	}   
	
	
	@Override
	public Product addproduct(Product pro)
	{
		
		
	//	for(int i=0;i<prod.length-1;i++)
		//{
			prod [i]=new Product();
			prod[i].setId(pro.getId());
			prod[i].setName(pro.getName());
			prod[i].setPrice(pro.getPrice());
			prod[i].setDescription(pro.getDescription());
		 
		i++;
		
		//}
		
		// TODO Auto-generated method stub
		return pro;
	}

	@Override
	public Product[] showAll() {
		
		
		
		
		// TODO Auto-generated method stub
		return prod;                   
	}

}
