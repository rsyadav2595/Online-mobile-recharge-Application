package com.cg.Productmanagmentsystem.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.cg.Projectmanagmentsystem.dto.Product;
import com.cg.Projectmanagmentsystem.service.IProductservice;
import com.cg.Projectmanagmentsystem.service.ProductService;

class Producttest {

	IProductservice service;
	Product prod;
	@BeforeEach
	public void beforetest()
	{
		service=new ProductService();
		prod=new Product();
		prod.setId(123);
		prod.setName("motorolla");
		prod.setPrice(3456);
		prod.setDescription("good");
		
	}
	
	@Test
	public void mytest()
	{
		assertNotNull(service.addProduct(prod));
	}
	
	
@Test
public void mytesttwo()
{
	assertNotNull(service.showAllProduct());
}
	
	@AfterEach
	public void aftertest()
	{
		service=null;
	}

}
