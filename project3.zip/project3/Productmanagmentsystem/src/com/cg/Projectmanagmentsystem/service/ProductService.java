package com.cg.Projectmanagmentsystem.service;

import com.cg.Productmanagmentsystem.dao.IproductDao;
import com.cg.Productmanagmentsystem.dao.ProductDao;
import com.cg.Projectmanagmentsystem.dto.Product;

public class ProductService implements  IProductservice 
{
	IproductDao dao;
	public  ProductService()
	{
		dao=new ProductDao();
	}
	 
	@Override
	public Product addProduct(Product prod)
	{
		// TODO Auto-generated method stub
		return dao.addproduct(prod);
	}

	@Override
	public Product[] showAllProduct() 
	{
		// TODO Auto-generated method stub
		return dao.showAll();
	}

}
