package com.cg.Projectmanagmentsystem.service;

import com.cg.Projectmanagmentsystem.dto.Product;

public interface IProductservice {

public  Product addProduct(Product prod);
 
	public Product[]showAllProduct();


}
