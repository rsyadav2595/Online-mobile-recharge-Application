package com.cg.springsampledemotwo.sevice;

import java.util.List;

import com.cg.springsampledemotwo.dao.CustomerDao;
import com.cg.springsampledemotwo.dao.CustomerDaoImpl;
import com.cg.springsampledemotwo.dto.Customer;

public class CustomerServiceImpl  implements CustomerService{

	CustomerDao dao;
	
	
	
	



	public void setDao(CustomerDao dao) {
		this.dao = dao;
	}




	public List<Customer> FindAll() {
		
		return dao.FindAll() ;
	}
 
	
	
	
	
}
