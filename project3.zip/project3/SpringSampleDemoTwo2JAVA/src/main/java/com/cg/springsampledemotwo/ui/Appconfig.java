package com.cg.springsampledemotwo.ui;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.cg.springsampledemotwo.dao.CustomerDao;
import com.cg.springsampledemotwo.dao.CustomerDaoImpl;
import com.cg.springsampledemotwo.sevice.CustomerService;
import com.cg.springsampledemotwo.sevice.CustomerServiceImpl;

@Configuration
public class Appconfig {

	
	@Bean(name="service")
	public CustomerService getCustomerService()
	{
		CustomerServiceImpl service =new CustomerServiceImpl();
		
		service.setDao(getCustomerDao());
		
		return service;
	}

	@Bean("dao")
	public CustomerDao getCustomerDao()
	{
		
		
		
		return  new CustomerDaoImpl();
		
	}




}


