package com.cg.springsampledemotwo.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.springsampledemotwo.dto.Customer;

public class CustomerDaoImpl implements CustomerDao {

	public List<Customer> FindAll() {
		
		List<Customer> customers=new ArrayList<Customer>();
		
		Customer customer =new Customer();
		
		customer.setFirstname("Radhika");
		customer.setLastname("yadav");
		customers.add(customer);
		
		return customers;
	}

}
