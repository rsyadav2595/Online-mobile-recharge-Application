package com.cg.springmvclabTwo.Service;

import java.util.List;

import com.cg.springmvclabTwo.dto.Trainee;

public interface TraineeService {

	
	public Trainee addTrainee(Trainee trainee);
	public void deleteTrainee(int id);
	public Trainee modifyTrainee(Trainee trainee);
	public Trainee retriveTrainee(int id);
    public List<Trainee>retriveAllTrainee();	
	
}
