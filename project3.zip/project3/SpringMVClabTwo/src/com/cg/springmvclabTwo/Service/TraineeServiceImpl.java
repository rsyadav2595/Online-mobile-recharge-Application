package com.cg.springmvclabTwo.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.cg.springmvclabTwo.dao.TraineeDao;
import com.cg.springmvclabTwo.dto.Trainee;


@Service
public class TraineeServiceImpl implements TraineeService{

	@Autowired
	TraineeDao TraineeDao;
	
	
	@Override
	public Trainee addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return  TraineeDao.saveTrainee(trainee);
	}

	@Override
	public void deleteTrainee(int id) {
	
		TraineeDao.removeTrainee(id);
	}

	@Override
	public Trainee modifyTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return TraineeDao.updateTrainee(trainee);
	}

	@Override
	public Trainee retriveTrainee(int id) {
		// TODO Auto-generated method stub
		return TraineeDao.retriveTrainee(id);
	}

	@Override
	public List<Trainee> retriveAllTrainee() {
		// TODO Auto-generated method stub
		return TraineeDao.retriveAllTrainee();
	}

}
