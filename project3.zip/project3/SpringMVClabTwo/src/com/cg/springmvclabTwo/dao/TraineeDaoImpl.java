package com.cg.springmvclabTwo.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.springmvclabTwo.dto.Trainee;


@Repository
public class TraineeDaoImpl implements TraineeDao {

	
	List<Trainee>mylist=new ArrayList<Trainee>();
	
	
	
	@Override
	public Trainee saveTrainee(Trainee trainee) {
		mylist.add(trainee);
		return trainee;
	}

	@Override
	public void removeTrainee(int id) {
		if(retriveTrainee(id)!=null)
		{
			mylist.remove(retriveTrainee(id));
		}
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return trainee;
	}

	@Override
	public Trainee retriveTrainee(int id) {
		
		return null;
	}

	@Override
	public List<Trainee> retriveAllTrainee() {
		
		return mylist;
	}

}
