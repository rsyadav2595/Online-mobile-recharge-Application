package com.cg.springmvclabTwo.dao;

import java.util.List;

import com.cg.springmvclabTwo.dto.Trainee;

public interface TraineeDao {

	

	public Trainee saveTrainee(Trainee trainee);
	public void removeTrainee(int id);
	public Trainee updateTrainee(Trainee trainee);
	public Trainee retriveTrainee(int id);//search
    public List<Trainee>retriveAllTrainee();	///show
	
	
	
}
