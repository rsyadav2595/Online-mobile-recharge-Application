package com.cg.springmvclabTwo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvclabTwo.Service.TraineeService;
import com.cg.springmvclabTwo.dto.Trainee;


@Controller
public class TraineeController {

	
	@Autowired
	TraineeService traineeservice;
	
	@RequestMapping(name="login",method=RequestMethod.GET)
	//@GetMapping("login")
	public String loginpage()
	{
	
		return "mylogin";
		
	}
	
    @PostMapping("checklogin")
	public String dologin(@RequestParam("uname") String user , @RequestParam("upass") String pass)
	{
		 
   	 if(user.equals("admin") && pass.equals("12345"))
   	 {
   		 return "listpage";
   	 }else {
   		 return "error";
   	 }
   	
	}

   	    @GetMapping("add")
   	    public ModelAndView  getTrainee (@ModelAttribute("treainee") Trainee trai)
     	 {
   		 
   	     List<String> Domainlist=new ArrayList<>();
   		 Domainlist.add("java");
   		 Domainlist.add("sql");
   		 Domainlist.add("dot net");
   		 return new ModelAndView( "addtrainee","domain",Domainlist);
   		 }
   	 
   	    
    	 @PostMapping("addtrainee")
	  public ModelAndView addtrainee(@ModelAttribute("treainee") Trainee trai) 
   	  {
		Trainee trainee=traineeservice.addTrainee(trai);
        return new ModelAndView("success","key",trainee);
	   }
   	    
    	  
   	     @GetMapping("retriveAll")
   	    public ModelAndView retriveAlltrainee() 
   	     {
			List<Trainee> myalltrainee=traineeservice.retriveAllTrainee();
			return new ModelAndView("retriveAlltreainee","retrivetrainee",myalltrainee);   //jsp page name,key name
   	    	
   	    }
   	 
   	     
   	 @GetMapping("delete")    
   	 public ModelAndView DeleteTrainee(@ModelAttribute("trainee") Trainee trai)
   	 {
   	   return new ModelAndView("delete");
      }
   	    
   	   @PostMapping("delete")
   	   public ModelAndView deletetrainee(@ModelAttribute("trainee") Trainee trai) 
   	   {
		
   	    	 traineeservice.deleteTrainee(trai.getId());
   	          return new ModelAndView("deleteData");
   		}
   	     
   	     
		
	}

