package com.cg.springmvcdemoone.service;

import java.util.List;

import com.cg.springmvcdemoone.dto.Product;

public interface ProductService {

	
	public Product AddProduct(Product pro);
	public List<Product>Showall();
	
	
	
}
