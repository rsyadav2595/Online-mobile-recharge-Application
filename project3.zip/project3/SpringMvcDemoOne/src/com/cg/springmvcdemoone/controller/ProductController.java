package com.cg.springmvcdemoone.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemoone.dto.Product;
import com.cg.springmvcdemoone.service.ProductService;

@Controller
public class ProductController 
{       
	@Autowired
	ProductService productservice;
	
	
	
	
	     //@RequestMapping(name="login",method=RequestMethod.GET)   both two are equivalent
	     @GetMapping("login")
         public String loginPage()
         {
			return "mylogin";
	
          }
	     
	     @PostMapping("checklogin")
	     public String dologin(@RequestParam("uname") String user , @RequestParam("upass") String pass)
	     {
	    	 
	    	 
	    	 if(user.equals("admin") && pass.equals("12345"))
	    	 {
	    		 return "listpage";
	    	 }else {
	    		 return "error";
	    	 }
	    	
		}
	     
	     
	    	 @GetMapping("addpage")
	    	 	public ModelAndView getProduct(@ModelAttribute("prod") Product pro)
	    	 	//MAPPING VIEW TO DTO
	    	 	//2nd way //public ModelAndView getProduct(@ModelAttribute("prod") Product pro,Map<String,Object> map)
	    	 	
	    	 	{
	    	 		List<String> listofCategory=new ArrayList<>();
	    	 		
	    	 		listofCategory.add("Electronics");
	    	 		listofCategory.add("Grocery");
	    	 		listofCategory.add("Cloths");
	    	 		return new ModelAndView("addproduct","cato",listofCategory);
	    	 		//2nd way //map.put("cato",listofCategory)
	    	 		//no need //return new ModelAndView("addproduct");
	    	 	} 
	    	 @PostMapping("addproduct")
	    	 	public ModelAndView addProduct(@ModelAttribute("prod") Product pro) {
	    	 		//System.out.println(pro);
	    	 		 Product product=productservice.AddProduct(pro);
	    	 		return new ModelAndView("success","key",product);  //only returning view
	    	 	} 
	    	 @GetMapping("showpage")
	    		public ModelAndView showProduct() {
	    			List<Product> myAllProduct=productservice.Showall();
	    			return new ModelAndView("showall", "showproduct", myAllProduct);
	    			//jsp page,key name==>showall jsp==>this can be used,value(obj)
	    		}

	     
}
