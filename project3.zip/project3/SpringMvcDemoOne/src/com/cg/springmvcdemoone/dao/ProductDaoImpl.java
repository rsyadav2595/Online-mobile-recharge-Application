package com.cg.springmvcdemoone.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvcdemoone.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao{

	@PersistenceContext         /////JPA
	EntityManager entitymanager;
	
	//List<Product>mylist=new ArrayList<Product>();    ///Collection
	
	@Override
	public Product save(Product pro) {
		

		entitymanager.persist(pro);
		entitymanager.flush();
		return pro;
		
		//mylist.add(pro);     /// Collection
		
	}

	  
	@Override
	public List<Product> Show()
	{
		
		Query query=entitymanager.createQuery("FROM Product");
		List<Product> mylist=query.getResultList();
		return mylist;
		
		//return mylist;   //// Collection
	
	}

}
