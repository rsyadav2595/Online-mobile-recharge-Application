package com.cg.ProductManagment.ui;

import java.util.List;
import java.util.Scanner;


import com.cg.ProductManagment.dto.Product;
import com.cg.ProductManagment.service.ProductService;
import com.cg.ProductManagment.service.ProductServiceImpl;



public class Myapplication {

	
	static ProductService  service;
	public Myapplication()
	{
		
	}
	
	
	
	public static void main(String[] args)
	{
		
		
			Scanner sc=new Scanner(System.in);
			service=new ProductServiceImpl();
					int choice=0;
			do {
				printDetails() ;
				System.out.println("Enter the choice");
				choice=sc.nextInt();
				switch(choice)
				{
					 
				case 1: 
					System.out.println("Enter the Id");
					int id=sc.nextInt();
					System.out.println("Enter name");
					String name=sc.next();
					System.out.println("Enter Description");
					String Description =sc.next();
					System.out.println("Enter the price");
					Double price=sc.nextDouble();
					
				
					Product pro=new Product();
					
					pro.setId(id);
					pro.setName(name);
					pro.setPrice(price);
					pro.setDiscription(Description);
				service.addproduct(pro);
			break;
			
				case 2: 
						  List<Product>mylist =service.showAll();
						   for(Product prodata:mylist) 
						   {
						    System.out.println("id is"   +prodata.getId());
						    System.out.println("name is"   +prodata.getName());
						    System.out.println("price is"  +prodata.getPrice());
						    System.out.println("Description is"   +prodata.getDiscription());
											
						    }
						   break; 
						   
				 			
				 case 3:
					System.out.println("Enter the name to search");
					String sname=sc.next();
					List<Product> prosearch=service.searchByName(sname);
					for (Product product : prosearch)
					{
						System.out.println("id is"   +product.getId());
					}
				
				break;
				
				}
			}
				while(choice!=6); 
				{
			
				
				
				}
				}
				
       private static void printDetails() 
     {
                     System.out.println("1.Add product");
					System.out.println("2.show product");
					System.out.println("3.search by name");
					System.out.println("4.update product");			
				

}
			}

	
