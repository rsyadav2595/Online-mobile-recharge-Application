package com.cg.ProductManagment.service;

import java.util.List;


import com.cg.ProductManagment.dao.ProductDao;
import com.cg.ProductManagment.dao.ProductDaoImpl;
import com.cg.ProductManagment.dto.Product;

public class ProductServiceImpl  implements ProductService{
	
	ProductDao dao;	
	
public ProductServiceImpl() {
	dao=new ProductDaoImpl();
	}
	

	
	
	@Override
	public List<Product> searchByName(String name) {
		return dao.findBy(name);
	}

	@Override
	public Product searchById(int id) {
		return dao.findById(id);
	}

	@Override
	public List<Product> showAll() {
		return dao.showAll();
	}


	@Override
	public void addproduct(Product pro) {
		dao.save(pro);// TODO Auto-generated method stub
		
	}

}
