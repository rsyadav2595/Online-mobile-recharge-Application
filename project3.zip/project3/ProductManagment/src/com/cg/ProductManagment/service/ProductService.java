package com.cg.ProductManagment.service;

import java.util.List;

import com.cg.ProductManagment.Exception.ProductException;
import com.cg.ProductManagment.dto.Product;


public interface ProductService {

	
	public void addproduct(Product pro) ;
	public List<Product>searchByName(String name);
	public Product searchById(int id)throws  ProductException ;
	
	public List<Product>showAll();
  
	
}
