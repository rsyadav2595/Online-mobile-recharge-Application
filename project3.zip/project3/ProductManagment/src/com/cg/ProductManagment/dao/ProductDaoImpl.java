package com.cg.ProductManagment.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.ProductManagment.Exception.ProductException;
import com.cg.ProductManagment.dto.Product;

public class ProductDaoImpl implements ProductDao {

	List<Product> Productdata;
	
	 public ProductDaoImpl()
	 {
		 Productdata=new ArrayList<Product>();
	
	}

	
	 
	 @Override
	public Product save(Product pro) {
		Productdata.add(pro);
		return pro;
		
	}

	@Override
	public List<Product> findBy(String name) {
		List<Product>productSearch=new ArrayList<>();
		for (Product pro : Productdata) {
			if (pro.getName().equals(name));
			productSearch.add(pro);
		}
		return productSearch;
	
	}

	@Override
	public Product findById(int id) {

		for (Product pro : Productdata) {
			if(pro.getId()==id) {
				return pro;
			}
		}
		return null;
	}

	@Override
	public List<Product> showAll() {
		// TODO Auto-generated method stub
		return Productdata;
	}

}
