package com.cg.ProductManagment.dao;

import java.util.List;

import com.cg.ProductManagment.Exception.ProductException;
import com.cg.ProductManagment.dto.Product;



public interface ProductDao {
	public Product save(Product pro);
	public List<Product>findBy(String name); 
	public Product findById(int id)throws ProductException ;
	public List<Product> showAll();
}
