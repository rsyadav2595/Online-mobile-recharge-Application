package demo2;

public class Abc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	/*Float[] theval= {10.0f,2.0f,3.0f};
		float sum =0.0f;
	for( float currentval:theval)
		sum +=currentval; */
		
	int val =10;
	switch (val % 2) 
	{
	case 0:
		System.out.print(val);
		System.out.println(" is even");
		
		break;

	default:
		break;
	}
	
	
	
	
	}

}
