package com.cg.Demo3.dto;

public class Proabc {

	
	  private int proId;
	  private String proName;
	  private double procost;
	public int getProId() {
		return proId;
	}
	public void setProId(int proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public double getProcost() {
		return procost;
	}
	public void setProcost(double procost) {
		this.procost = procost;
	}
}
	 
	