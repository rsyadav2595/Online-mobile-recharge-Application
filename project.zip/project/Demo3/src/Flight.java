
public class Flight {

	private int passenger;
    private int seat;
	 public Flight()
	 {
		 passenger=0;
		 seat=20;
	 }
	void  addpassenger()
	{
		if(passenger<seat)
			passenger +=1;
		else handletomany();
		
	}
void handletomany()
{
	System.out.println("to many");
}
}
