package com.cg.DemoCollection.dto;

import java.util.Comparator;

public class EmployeeSorting implements Comparator<Employee>{

	public int compare(Employee o1, Employee o2) {
		
//		
//		if(o1.getId()<o2.getId()) {
//			return 1;
//			
//		}else if (o1.getId()>o2.getId()) {
//			return -1;
//		}else return 0;
//		
		
		
		return o1.getName().compareToIgnoreCase(o2.getName());
		
	}

}
