package com.cg.DemoCollection.ui;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeMap;
import java.util.TreeSet;

import com.cg.DemoCollection.dto.Employee;
import com.cg.DemoCollection.dto.EmployeeSorting;

public class Myapplication {

public static void main(String args[])
	 {
		
	
	
   
//	Employee<Integer,Double> emp=new Employee<Integer,Double>(123,"er",78.0);
//	Employee<Integer,Double> empone=new Employee<Integer,Double>(123,"er",78.0);
	 ////for generics////
	
	
	Map<Integer, String> mymap=new HashMap<Integer, String>();
	
	
	mymap.put(123, "a");
	mymap.put(111, "R");
	mymap.put(124, "A");
	mymap.put(125, "s");
	
	TreeMap<String, Integer>mm=new TreeMap<String, Integer>();
			
			System.out.println(mm.keySet());
	
	//System.out.println(mymap);
	       //////  System.out.println(mymap.keySet());    sorted in map by using keyset
	
   
	//////sorted by name in map/////////
	
// Collection<Employee>mycollection=mymap.values();
// List<Employee>emplist=new ArrayList<Employee>(mycollection);
// Collections.sort(emplist, new EmployeeSorting());
//  for (Employee employee : emplist) {
//	System.out.println("Name is"+employee.getName());
//  }
//	  
	//////////////////////////////////////////
	
	
	
	
	
//	Set<Employee > myset=new TreeSet<Employee >();
	
	//Set<Employee > myset=new HashSet<Employee >();
//	myset.add("q");
//	myset.add("w");
//	myset.add("A");
	
	//myset.add("A");                          /////duplicate not allow in tree set
//	Employee emp=new Employee(40,"bbu",6656);
//	Employee empone=new Employee(62,"fby",6856);
//	Employee emptwo=new Employee(37,"zbb",6466);
//	
//	
//	List<Employee>myset=new ArrayList<Employee>();
//  
//	Collections.sort(myset, new EmployeeSorting());
//	
//	myset.add(emp);
//    myset.add(empone);
//	myset.add(emptwo);
//	
	//System.out.println(myset);
	//List<Employee>mylist=new ArrayList<Employee>(myset);
	
	//Collections.shuffle(mylist);

	
//	Collections.sort(mylist);
//	for (Employee employee : mylist) {
//		System.out.println(employee.getName());
//	}

	//System.out.println(myset);
//	Set<String>my=new TreeSet<String>();
//	my.add("r");
//	
	
	
//	String str="GB";
//	String  str1="eb";
//	
//	System.out.println(str.hashCode()+" "+str1.hashCode());
//	System.out.println(str.equals(str1));
//	
//	

//	Set<Employee> myset=new HashSet<Employee>();
//	
//	Employee emp=new Employee(1,"abc",6456);
//	Employee empone=new Employee(1,"abc",6456);
//	Employee emptwo=new Employee(1,"abc",6456);
//	
//	myset.add(emp);
//	myset.add(empone);
//	
//	myset.add(emptwo);
	//Set<String> myset=new HashSet<String>();
	
	
//	myset.add("y");
//	myset.add("r");
//	myset.add("p");
	//myset.add("p");    
	
	//System.out.println(myset);
	
	 
	 
	 }
}
