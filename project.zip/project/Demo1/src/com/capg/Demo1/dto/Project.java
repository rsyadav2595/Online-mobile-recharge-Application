package com.capg.Demo1.dto;

public class Project {
 public Project(int projId, String projname, Double projcost, String projDeg) {
		super();
		this.projId = projId;
		this.projname = projname;
		this.projcost = projcost;
		this.projDeg = projDeg;
	}
public Project() {
	// TODO Auto-generated constructor stub
}
private int projId;
 private String projname;
 private Double projcost;
 private String projDeg;
public int getProjId() {
	return projId;
}
public void setProjId(int projId) {
	this.projId = projId;
}
public String getProjname() {
	return projname;
}
public void setProjname(String projname) {
	this.projname = projname;
}
public Double getProjcost() {
	return projcost;
}
public void setProjcost(Double projcost) {
	this.projcost = projcost;
}
public String getProjDeg() {
	return projDeg;
}
public void setProjDeg(String projDeg) {
	this.projDeg = projDeg;
}
@Override
public String toString() {
	return "Project [projId=" + projId + ", projname=" + projname + ", projcost=" + projcost + ", projDeg=" + projDeg
			+ "]";
}
}
