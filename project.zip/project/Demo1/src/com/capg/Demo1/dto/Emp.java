package com.capg.Demo1.dto;

public class Emp 
{
  public Emp(int empId, String empName, double empSallery, String empDeg, Project proj) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSallery = empSallery;
		this.empDeg = empDeg;
		this.proj = proj;
	}
  
  public Emp()  
  {
	  
  }
private int empId;//0
  private String empName;//null
  private double empSallery;//0.0
  private String empDeg;//null
  private Project proj;//null
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public double getEmpSallery() {
	return empSallery;
}
public void setEmpSallery(double empSallery) {
	this.empSallery = empSallery;
}
public String getEmpDeg() {
	return empDeg;
}
public void setEmpDeg(String empDeg) {
	this.empDeg = empDeg;
}
public Project getProj() {
	return proj;
}
public void setProj(Project proj) {
	this.proj = proj;
}
@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + ", empSallery=" + empSallery + ", empDeg=" + empDeg
			+ ", proj=" + proj + "]";
}
  
 /* public Emp()             //////////Default constructor
  {
	   System.out.println("......in constructor.......");
     }
  public Emp (int id,String name,double sallery)     ///// parameterised constructor
{
	this.empId=id;
	this.empName=name;
	this.empSallery=sallery;
}
    public void getLogin()
    {
	 int local=10;
	  System.out.println(" ....get login.... ");
	  System.out.println("Id is="   +this.empId);
	  System.out.println("Name is=" +this.empName);
	  System.out.println("sallery=" +this.empSallery);
	  System.out.println(local);
	  
	  }     *//////
  
  
  
 /* public void getLogout() {
	  System.out.println("....get logout.....");
	  
	   }
  public int getempid() {
	  return empId;
  }
  public void setempid(int empid)
  {
	  this.empId=empid;
  }
  
  public String getempName()
  {
	  return empName;
  }
  public void setempname(String empName)
  {
	  this.empName=empName;
  }
  
  public double getempSallery()
  {
	  return empSallery;
  }
  public void setempSallery(double empsallery)
  {
	  this.empSallery=empsallery;
  }
@Override
public String toString() {
	return "Emp [empId=" + empId + ", empName=" + empName + ", empSallery=" + empSallery + ", empDeg=" + empDeg + "]";
}*/
}
