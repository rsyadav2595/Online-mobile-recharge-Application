package com.capg.Demo1.ui;
import java.util.Scanner;

import com.capg.Demo1.dto.Emp;
import com.capg.Demo1.dto.Project;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("hello......." +args[0]);
	/* Emp emp1= new Emp();       ////////default const
		Emp emp= new Emp(111,"radha",122345);
		emp.getLogin();
      emp.getLogout(); */

	
	
	//Emp emp=new Emp();
	//emp.setempid(12234);
	//emp.setempname("ABC");
//	emp.setempSallery(276488);
//	System.out.println("id of emp==="+emp.getempid());
//	System.out.println("name of emp==="+emp.getempName());
//	System.out.println("sallery of emp==="+emp.getempSallery());
	//System.out.println(emp);
//	
	Emp emp=new Emp();
	Project proj=new Project();
	
     //int id= Integer.parseInt(args[0]);             ///////Wrapper classes we are used here
	//String name=args[1];
	//double sal=Double.parseDouble(args[2]);
	//String deg=args[3];
	
	//int projId=Integer.parseInt(args[4]);             //////wrapper classess
	//String projName=args[5];
	//double projcost=Double.parseDouble(args[6]);
	//String projDeg=args[7];   
	Scanner scr= new Scanner(System.in); /// console to application data 
	
	System.out.println("Enter the Emp Id");
	int id=scr.nextInt();
	System.out.println("Enter the name");
	String name=scr.next();
	System.out.println("Enter the sallery");
	double sal=scr.nextDouble();
	System.out.println("Enter the deg");
	String deg=scr.next();
	
	System.out.println("Enter proj Id");
	int projId=scr.nextInt();
	System.out.println("Enter proj name");
	String projName=scr.next();
	System.out.println("Enter proj cost");
	double projcost=scr.nextDouble();
	System.out.println("Enter proj deg");
	String projdeg=scr.next();
	
	
	emp.setEmpId(id);
	emp.setEmpName(name);
	emp.setEmpSallery(sal);
	emp.setEmpDeg(deg);
	
	proj.setProjId(projId);
	proj.setProjname(projName);
	proj.setProjcost(projcost);
	proj.setProjDeg(projdeg);
	
	
	emp.setProj(proj);
//	System.out.println(emp);        /////////print both emp and project details if you put this line
	System.out.println("project Id=" +emp.getProj().getProjId());     ////////////print only project details
	System.out.println("project Name="+emp.getProj().getProjname()); ////////print only project details
	
	System.out.println("project cost="+emp.getProj().getProjcost());   ///////print only project details
	System.out.println("project deg="+emp.getProj().getProjDeg());     /////////print only project details
	
	
	
	//emp.getProj().setProjId(12);
//	emp.getProj().setProjname("GE");
//	emp.getProj().setProjcost(67899.12);
//	emp.getProj().setProjDeg("java spring");
//	System.out.println(emp);
	
	
	
	}
		
}
