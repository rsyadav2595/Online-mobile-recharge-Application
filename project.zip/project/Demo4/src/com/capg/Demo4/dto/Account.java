package com.capg.Demo4.dto;

public class Account {

	public Account(int accountId, String accountname, Double accountbalance) {
		super();
		this.accountId = accountId;
		this.accountname = accountname;
		this.accountbalance = accountbalance;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	private int accountId;
	 private String accountname;
	 private Double accountbalance;
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountname() {
		return accountname;
	}
	public void setAccountname(String accountname) {
		this.accountname = accountname;
	}
	public Double getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(Double accountbalance) {
		this.accountbalance = accountbalance;
	}
	@Override
	public String toString() {
		return "Account [accountId=" + accountId + ", accountname=" + accountname + ", accountbalance=" + accountbalance
				+ "]";
	}
	 

}
