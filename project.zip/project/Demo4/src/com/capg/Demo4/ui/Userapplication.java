package com.capg.Demo4.ui;

import com.capg.Demo4.dto.Account;
import com.capg.Demo4.dto.User;

public class Userapplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Account acc=new Account();
		User user=new User();
	 acc.setAccountId(12);
	 acc.setAccountname("asdf");
	 acc.setAccountbalance(234.6);
		
	  user.setUserId(23);
	  user.setUsername("abc");
	  user.setUseradd("capgemini");
		
	//  user.setAcc(acc);
	  
	System.out.println(acc); 
		
	}

}
