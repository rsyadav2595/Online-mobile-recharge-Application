package com.cg.CollectionTwo.service;
                                           //////////////buseness logic//////
import java.util.List;

import com.cg.CollectionTwo.dao.EmpDao;
import com.cg.CollectionTwo.dao.EmpDaoImpl;
import com.cg.CollectionTwo.dto.Emp;
import com.cg.CollectionTwo.exception.EmpException;

public class EmpserviceImpl implements Empservice {
    EmpDao dao;
	public  EmpserviceImpl()
	{
		dao=new  EmpDaoImpl();
	}
	
	@Override
	public void addEmployee(Emp emp) {
		// TODO Auto-generated method stub
		
		emp.setSallery(emp.getSallery()+emp.getSallery()*0.1);   /////for increasing sal//
		dao.save(emp);
			}

	@Override
	public List<Emp> searchByName(String name) {
		// TODO Auto-generated method stub
		return dao.findBy(name);
	}

	@Override
	public Emp searchById(int id)throws EmpException {
	     return dao.findById(id);
	}

	@Override
	public List<Emp> showAll() 
	{
		return dao.showAll();
	}
    @Override
	public Emp update(Emp emp) throws EmpException
	{
		return null;
	}
@Override
	public void sort() {
		
	}

}
