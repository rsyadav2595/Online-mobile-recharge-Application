package com.cg.CollectionTwo.service;

import java.util.List;

import com.cg.CollectionTwo.dto.Emp;
import com.cg.CollectionTwo.exception.EmpException;

public interface Empservice          ///generic interface T means string, int,double
{

	
	
	public void addEmployee(Emp emp) ;
	public List<Emp>searchByName(String name);
	public Emp searchById(int id) throws EmpException;
	
	public List<Emp>showAll();
    public Emp update(  Emp emp);   ///id is uniq so return type is Emp
    public  void sort();




}
