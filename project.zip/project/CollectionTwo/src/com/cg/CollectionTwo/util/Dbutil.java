package com.cg.CollectionTwo.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.CollectionTwo.exception.EmpException;

public class Dbutil {

	
	
	
	static Connection con;
	public static Connection getConnection()
	{
		Properties prop=new Properties();
		try {
			InputStream in=new FileInputStream("src/main/resource/jdbc.properties");
			prop.load(in);
			
		
				if(prop!=null)
				{
					String driver =prop.getProperty("jdbc.driver");
					String url=prop.getProperty("jdbc.url");
					String uname=prop.getProperty("jdbc.username" );
					String upass=prop.getProperty("jdbc.upas");
					Class.forName(driver);
					con=DriverManager.getConnection(url,uname,upass);
					
 					}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new EmpException("File not found");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		return con;
		
	}
	
}
