package com.cg.CollectionTwo.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.CollectionTwo.dto.Emp;
import com.cg.CollectionTwo.exception.EmpException;
import com.cg.CollectionTwo.util.Dbutil;

public class EmpDaoImpl implements EmpDao {

	List<Emp> empData;
	 public EmpDaoImpl()
	 {
		 empData=new ArrayList<Emp>();
	 }
	 
	@Override
	public Emp save(Emp emp) {
		// TODO Auto-generated method stub
		                                     ///////JDBC CONNECTION for adding data//////
	//Connection con=Dbutil.getConnection();
    //    String query_insert="INSERT INTO employee VALUES(?,?,?) "	
	//	try{
	//	PrepareStatment pstm=con.prepareStatement (quey_insert);
		//pstm.setInt("1",emp.getId());
		//pstm.setString(emp.getName());
	//	pstm.setdouble(emp.getSallery());
	//	pstm.executeupdate();
	//}catch(SQL exception e) {
		
	///e.printstacktrace
	//}
		//finally
		//{
//		try {
//			pstm.close();
//			con.close();
//		}catch(SQLException e){
//			e.printStackTrace();
//			throw new EmpException ("Connection not closed");
//		}
		//}
	//	return emp;
//	}
		
		
		
		empData.add(emp);
		return emp;
	}
   @Override
	 public List<Emp> findBy(String name)    ////search name by using list
	{ 
		List<Emp>empSearch=new ArrayList<>();
		for (Emp emp : empData) {
			if (emp.getName().equals(name));
			empSearch.add(emp);
		}
		return empSearch;
	}

	@Override
	public Emp findById(int id) throws EmpException	{
	
		for (Emp emp : empData) {
			if(emp.getId()==id) {
				return emp;
			}else {
				throw new EmpException("id not found");
			}
		}
		return null;
	}
     @Override
	public List<Emp> showAll() {
		
//		                              ////////JDBC CONNECTION /////////
    	 
//    	 Connection con =Dbutil.getConnection();
//    	 String Query_show="SELECT emp_id,emp_name,emp_salary FROM Emp";
//    	 Preparestatment pstm=null;
//    	 List<Emp>mylist=new ArrayList<Emp>();
    	 //try {
//    	pstm= con.preparestatment(Query_show);
//    	ResultSet result=pstm.executequery();
//    	while(result.next())
//    	{
//    		Emp emp=new Emp();
//    		emp.setId(result.getInt("emp_id"));
//    		emp.setName(result.getString("emp_name"));
//    		emp.setSallery(result.getDouble("emp_salary"));
//    		mylist.add(emp);
//    	}catch(SQLEXception e)
    	 //{
//    	 throw new EmpException("Show not found");
//     }
//     finally {
//    	 try {
//    		 pstm.close();
//    		 con.close();
//    	 }catch (SQLException e){
    	// e.printstacktrace();
//    	 
//    	 return mylist;
    	 return empData;
	}


}
