package com.cg.CollectionTwo.dao;

import java.util.List;

import com.cg.CollectionTwo.dto.Emp;
import com.cg.CollectionTwo.exception.EmpException;


public interface EmpDao {
public Emp save(Emp emp);
public List<Emp>findBy(String name); 
public Emp findById(int id) throws EmpException;
public List<Emp> showAll();

}
