package com.cg.Demomaven.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Myapplication {

	@Test
	void test() {
		System.out.println("in test=====");
	}

}
