package com.cg.CollectionDemoNew.ui;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.cg.CollectionDemoNew.dto.Person;




public class Myapplication {

	public static void main(String[] args) {
		
		
		
		
		
		
		Person preson=new Person("Ankita");
		Person presonone=new Person("Radhika");
		Person presontwo=new Person("sonal");
		Person presonthree=new Person("rutu");
		Person presonfour=new Person("nikita");
		Person presonfive=new Person("aish");
		Person presonsix=new Person("tanaya");
		Person presonseven=new Person("anu");
		Person presoneight=new Person("manu");
		Person presonnine=new Person("manu");
		
		Set<Person> myset=new HashSet<Person>();

		
		myset.add(preson);
		myset.add( presonone);
		myset.add(presontwo);
		myset.add(presonthree);
		myset.add(presonfour);
		myset.add(presonfive);
		myset.add(presonsix);
		myset.add(presonseven);
		myset.add(presoneight);
		myset.add(presonnine);
		
		
	
		
     System.out.println(myset);
		 
		
		
		}
 
		

	
	
	}


