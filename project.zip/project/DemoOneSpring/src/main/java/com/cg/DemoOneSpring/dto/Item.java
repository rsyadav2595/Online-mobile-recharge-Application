package com.cg.DemoOneSpring.dto;

public class Item {
	
	
	
	private int id;
	 private String shopname;
		
	
      public Item(int id, String shopname)   //constructor
      {
	
		this.id = id;
		this.shopname = shopname;
	}



	
	
	
	public Item() {
		System.out.println("in Item");
	}

	
	
	
	public void getData()
	{
		System.out.println("hiiii");
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getShopname() {
		return shopname;
	}


	public void setShopname(String shopname) {
		this.shopname = shopname;
	}
}
