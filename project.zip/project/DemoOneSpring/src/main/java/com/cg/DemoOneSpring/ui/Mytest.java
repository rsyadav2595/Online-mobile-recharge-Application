package com.cg.DemoOneSpring.ui;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.DemoOneSpring.dto.Item;
import com.cg.DemoOneSpring.dto.Product;

public class Mytest {

	public static void main(String[] args)
	{
		
		
		
		ApplicationContext app=new ClassPathXmlApplicationContext("spring.xml");
	
		Product p=(Product)app.getBean("prod");
//		p.setId(101);
//		p.setName("mobile");
//		p.setPrice(123243.8);
//		p.setDescription("---sony----");
		p.getAllData(); 
//		
//	    Item i=(Item)app.getBean("it");
//	    i.getData();
	
	}

}
