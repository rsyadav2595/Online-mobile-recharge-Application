package com.cg.Collection.ui;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Demo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	List<String> mylist=new LinkedList<String>();
	
	mylist.add("LIST");
	mylist.add("list");
	mylist.add("liiist");

for(String list:mylist)   //// 2nd way for printing
{
	System.out.println(list);   
}
	
 System.out.println("____________________________________________________");

//        Iterator<String> it=mylist.iterator();
//        while(it.hasNext()) {
//	    System.out.println(it.next());
}
  }


