package com.cg.Collection.ui;

import java.util.Iterator;
import java.util.TreeSet;
	
	TreeSet map = new TreeSet();
    map.add("one");
    map.add("two");
    map.add("three");
    map.add("one");
    map.add("four");
    Iterator it = map.iterator();
    while (it.hasNext() ) 
          System.out.print( it.next() + " " );


