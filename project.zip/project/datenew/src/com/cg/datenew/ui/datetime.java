package com.cg.datenew.ui;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class datetime {

	public static void main(String[] args)  {
	
		
		
		
		////for current time of any city///////
		
		ZonedDateTime zone=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(zone);
		
		
		
		}
	}	
		
		
		
	







//////local date/////


//		LocalDateTime localDate= LocalDateTime.now(); 
//		
//		
//		System.out.println(localDate.plusDays(2));
//		
//		
		
		
		////////current date //////	
	
//		datetime date=new datetime();
//		Scanner src =new Scanner(System.in);
//		System.out.println("Enter the date");
//		String str=src.next();
		
		
		
//		SimpleDateFormat format=new SimpleDateFormat("yyyy/mm/dd");   
//		
//		Date givendate=format.parse(str);
//		System.out.println(givendate);
		
	
