

//public class Demo2{
//int size = 7;
//public static void main(String[] args) {
//	Demo2 m1 = new Demo2();
//	Demo2 m2 = m1;
//int i1 = 10;
//int i2 = i1;
//go(m2, i2);
//System.out.println(m1.size + " " + i1);
//}
//static void go(Demo2 m, int i) {
//m.size = 8;
//i = 12;
//}
//}
 
//class Demo2{
//	Demo2() { }
//	Demo2(Demo2 m) { m1 = m; }
//	Demo2 m1;
//public static void main(String[] args) {
//	Demo2 m2 = new Demo2();
//	Demo2 m3 = new Demo2(m2); m3.go();
//	Demo2 m4 = m3.m1; m4.go();
//	Demo2 m5 = m2.m1; m5.go();
//}
//void go() { System.out.print("hi "); }
//}
//




class  Demo2 {
 static int players = 0;
 public static void main (String [] args) 
 {
 System.out.println("players online: " +  players);
 
 System.out.println("The value of players is "
+  players++);
 
 System.out.println("The value of players is now "
+ players);

 }

}



















