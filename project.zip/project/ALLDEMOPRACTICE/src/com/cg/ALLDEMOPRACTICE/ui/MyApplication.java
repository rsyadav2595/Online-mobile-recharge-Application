package com.cg.ALLDEMOPRACTICE.ui;

import java.util.TreeMap;
import java.util.TreeSet;


	
//
//public static void main(String[] args){
//	  TreeMap tree = new TreeMap();
//	  tree.put("India", 1);
//	  tree.put("China", 2);
//	  tree.put("Nepal", 3);
//	  tree.put("Bhutan", 4);
//	  System.out.println(tree);
//	 }
//}
public class MyApplication  {
	 public static   void main(String[] args) throws InterruptedException {
	  Thread t = new Thread();
	  t.start();
	  
	  System.out.print("X");
	  
	   t.wait(10000);
	  
	  
	  System.out.print("Y");
	 }

	  
	}