package com.cg.Demomaven.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.ObjectOutputStream.PutField;
import java.io.OutputStream;

//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.FileOutputStream;
//import java.io.FileReader;
//import java.io.FileWriter;
//import java.io.IOException;
//import java.io.InputStream;
//import java.io.OutputStream;
//import java.io.Reader;
//import java.io.Writer;
//import java.util.StringTokenizer;

public class Myapplication {

	public static void main(String[] args) {
		
		
		Employee emp=new Employee(1234,"ABCFD",123.9);
		InputStream fileread;
		Employee empread=null;
  try {
		 fileread=new FileInputStream("D:/Myobject.txt");
		ObjectInput objectread=new ObjectInputStream(fileread);
		empread=(Employee) objectread.readObject();
		objectread.close();
		System.out.println(empread);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block

		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		try {
			OutputStream filewrite=new FileOutputStream("D:/Myobject.txt");
			ObjectOutput objectwrite=new ObjectOutputStream(filewrite);
			objectwrite.writeObject(emp);
			objectwrite.flush();
			objectwrite.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("file not found");
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("file not write");
		}
		
		
			
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	
		
		
		
		
		// TODO Auto-generated method stub
		
//		String str="Cpgemini".intern();
//		String str1=new String("capgemini");
//		System.out.println(str.hashCode());
//		//String str1="Igate";
//		
//		System.out.println(str1.hashCode());
//		System.out.println(str==str1);
//		System.out.println(str.equals(str1));
		
		
		
//		String str="Capgemini";
//		//System.out.println(str.substring(2,5));
//		StringBuffer sb=new StringBuffer("capgemini");
//		System.out.println(sb.hashCode());
//		sb.append("good");
//		System.out.println(sb.hashCode());
//		
	
	//StringBuilder sb=new StringBuilder();
//	StringTokenizer str=new StringTokenizer("capgemini ,is good,rrrrr", ",");
//	while(str.hasMoreTokens()) 
//	System.out.println(str.nextToken());
//	System.out.println(str.nextToken(","));
//	
//	Reader read=null;
//	Writer Filewrite=null;
//	BufferedReader bufreader=null;
//	BufferedWriter bufwriter=null;
//	try {
//		 read=new FileReader("Myread.txt");
//		 bufreader=new BufferedReader(read);
//		 
//	 Filewrite=new FileWriter ("Mywrite.txt") ;
//	 bufwriter =new BufferedWriter(Filewrite);
//	 
//	 String data=null;
//		
//		//int data=0;
//		while((data= bufreader.readLine())!=null)
//			Filewrite.write(data);
//		{
//			
//		}
//		
//	} catch (FileNotFoundException e) {
//		// TODO Auto-generated catch block
//	
//		System.out.println("file not found");
//	} catch (IOException e) {
//		// TODO Auto-generated catch block
//		System.out.println("file not /readopen");
//		
//	}
//		finally
//		{
//			try {
//				read.close();
//				Filewrite.close();
//			}  catch(IOException e)
//			{
//				System.out.println("file not close");
//			}
//		}
//		
//		
//		
//		
//		
		
	