package com.cg.Demomaven.ui;

import java.io.Serializable;

public class Employee implements Serializable {

	public Employee(int empId, String empName, double empsal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empsal = empsal;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	int empId;
	String empName;
	double empsal;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpsal() {
		return empsal;
	}
	public void setEmpsal(double empsal) {
		this.empsal = empsal;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empsal=" + empsal + "]";
	}
	
}
