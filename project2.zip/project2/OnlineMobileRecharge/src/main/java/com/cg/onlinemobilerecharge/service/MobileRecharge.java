package com.cg.onlinemobilerecharge.service;

public interface MobileRecharge {

}
