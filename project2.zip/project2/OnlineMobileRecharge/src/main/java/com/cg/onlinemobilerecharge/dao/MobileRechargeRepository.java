package com.cg.onlinemobilerecharge.dao;

public interface MobileRechargeRepository {

}
