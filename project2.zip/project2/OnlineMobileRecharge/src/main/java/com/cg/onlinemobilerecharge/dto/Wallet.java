package com.cg.onlinemobilerecharge.dto;

public class Wallet {

}
