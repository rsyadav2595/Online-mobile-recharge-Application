package com.cg.onlinemobilerecharge.dto;

import java.util.List;

public class Customer
 {
     public Customer() 
     {
		super();
		// TODO Auto-generated constructor stub
	}
public Customer(String name, String email, List<Mobile> mobileno)
{
		super();
		this.name = name;
		this.email = email;
		this.mobileno = mobileno;
	}
   private String name;
   private String email;
   private List<Mobile>mobileno;
  public String getName() {
	return name;
}
 public void setName(String name) {
	this.name = name;
}
 public String getEmail() {
	return email;
}
 public void setEmail(String email) {
	this.email = email;
}
 public List<Mobile> getMobileno() {
	return mobileno;
}
public void setMobileno(List<Mobile> mobileno) {
	this.mobileno = mobileno;
}
@Override
public String toString() {
	return "Customer [name=" + name + ", email=" + email + ", mobileno=" + mobileno + "]";
}
	

 
 } 
