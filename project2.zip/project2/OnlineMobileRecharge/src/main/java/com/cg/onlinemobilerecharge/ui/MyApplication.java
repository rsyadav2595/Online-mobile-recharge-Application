package com.cg.onlinemobilerecharge.ui;

public class MyApplication {

	public static void main(String[] args) {
		

	}

}
