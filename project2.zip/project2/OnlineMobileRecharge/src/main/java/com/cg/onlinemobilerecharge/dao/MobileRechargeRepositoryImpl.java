package com.cg.onlinemobilerecharge.dao;

public class MobileRechargeRepositoryImpl {

}
