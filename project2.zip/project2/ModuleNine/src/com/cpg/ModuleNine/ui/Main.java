
package com.cpg.ModuleNine.ui;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Mathequation[] math=new Mathequation[2];
math[0]=new Mathequation('a',100.0d,0, 50.0d);
math[1]=new Mathequation('s',100.0d,0, 50.0d);		
		
		
		for(Mathequation math1 = maths)
	{
           math.execute();
System.out.print("result");
System.out.println(math.getResult());
		
		
		}
		
		System.out.println();
		System.out.println("using overload");
		System.out.println();
		double leftval=9.0d;
		double rightval= 0.4d;
		
		Mathequation equation=new Mathequation('d', rightval, (char) 0, rightval);
		Object leftDouble;
		Object rightDouble;
		equation .execute(leftDouble,rightDouble);
		System.out.println("result==");
		System.out.println("equation.getResult");
	
	
	
		equation .execute(leftDouble,rightDouble);
		System.out.println("result==");
		System.out.println("equation.getResult");
	
	
	      Calculate[] calculator= {
	    		  new Adder (25.0d,4.0d),
	    		  new Sub(23.0d,5.0d)
	    	  };
	
	
	Object Calculators;
	for(Calculate calculator1: calculator) {
		Calculate Calculator;
		Calculator.Calculatemaths();
		System.out.println("get result==");
		System.out.println("Calculator.getresult");
	
	}
	
	
	
	
	}
}


