package com.cpg.ModuleNine.ui;

public abstract class Calculate {

	public Calculate(double leftval, double rightval, double result) {
		super();
		this.leftval = leftval;
		this.rightval = rightval;
		this.result = result;
	}


	private double leftval;
	private double rightval;
	private double result;


	public Calculate() {
		super();
		// TODO Auto-generated constructor stub
	}


	public double getLeftval() {
		return leftval;
	}


	public void setLeftval(double leftval) {
		this.leftval = leftval;
	}


	public double getRightval() {
		return rightval;
	}


	public void setRightval(double rightval) {
		this.rightval = rightval;
	}


	public double getResult() {
		return result;
	}


	public void setResult(double result) {
		this.result = result;
	}


	
	
	public abstract void Calculatemaths();
	{
		
	}
	
	
	
	
	
	@Override
	public String toString() {
		return "Calculate [leftval=" + leftval + ", rightval=" + rightval + ", result=" + result + "]";
	}







}




