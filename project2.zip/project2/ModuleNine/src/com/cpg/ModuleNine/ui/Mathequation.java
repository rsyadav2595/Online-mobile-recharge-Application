package com.cpg.ModuleNine.ui;

public class Mathequation {


	public Mathequation(double leftval, double rightval, int i, double result) {
		super();
		this.leftval = leftval;
		this.rightval = rightval;
		this.opcode = (char) i;
		this.result = result;
	}

	private double leftval;
	private double rightval;
	private char opcode= 'a';
	private double result;
	
	public Mathequation() {
		super();
		// TODO Auto-generated constructor stub
	}

	public double getLeftval() {
		return leftval;
	}

	public void setLeftval(double leftval) {
		this.leftval = leftval;
	}

	public double getRightval() {
		return rightval;
	}

	public void setRightval(double rightval) {
		this.rightval = rightval;
	}

	public char getOpcode() {
		return opcode;
	}

	public void setOpcode(char opcode) {
		this.opcode = opcode;
	}

	public double getResult() {
		return result;
	}

	public void setResult(double result) {
		this.result = result;
	}

	@Override
	public String toString() {
		return "Mathequation [leftval=" + leftval + ", rightval=" + rightval + ", opcode=" + opcode + ", result="
				+ result + "]";
	}



public void execute(Object leftDouble, Object rightDouble)
{
	switch(opcode) {
	
	
	case 'a':
		result=leftval+rightval;
		break;
		
	case 's':
		result=leftval-rightval;
		break;
	
	default:
		System.out.println("error-invalid opcode");
		break;
	
	
	
	
	
	}
	
	
	
	
	
}
}



