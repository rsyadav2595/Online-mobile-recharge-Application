package com.cpg.ModuleNine.ui;

public class Adder extends Calculate 
{
	
	public Adder()
	{
	
	}
	
	
	public Adder(double leftval,double rightval) {
	}{
		Object rightval;
		Object leftval;
		
	}
	
	
	@Override
	public void Calculatemaths() {
		
		double val=getLeftval()+getRightval();
		double values;
		setResult(values);
	}
	
}

