package com.cpg.ModuleNine.ui;

public class Sub extends Calculate {
 
	public Sub() {
	}
	{
		
	}
	public Sub(double leftval,double rightval) {
	}
	
	
	
	
	@Override
	public void Calculatemaths() {
		
		double val=getLeftval()-getRightval();
		double values = 0;
		setResult(values);
	}
	
}
	
	

