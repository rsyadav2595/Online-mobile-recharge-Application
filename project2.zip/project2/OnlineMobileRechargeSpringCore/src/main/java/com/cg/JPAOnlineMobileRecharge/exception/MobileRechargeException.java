package com.cg.JPAOnlineMobileRecharge.exception;

public class MobileRechargeException  extends RuntimeException {
  
	
	public MobileRechargeException()
	{
		
	}
	

	public MobileRechargeException(String msg)
	{
		super(msg);
	}
	
	
}
