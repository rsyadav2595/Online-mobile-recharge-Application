package com.cg.LabFiveFibo.ui;

import java.util.Scanner;

public class Fibo
{                                    /////nonrecursion

	public static void main(String[] args) {

	         	int i,a=1,b=1,c=0,t;
			
	         	Scanner scr=new Scanner(System.in);
				
				
			System.out.println("Enter the t:");

			   t=scr.nextInt();
				System.out.print(a); 
				
				
				System.out.print(" "+b);
				for(i=0;i<t-2;i++)
				{
					c=a+b;
					a=b;
					b=c;
					System.out.print(" "+c);
				}
				System.out.println();
				System.out.print(t+"the of the series is: "+c);
			
	
	
	
	
	
	
	}

}
