package com.cg.Polymorphism.ui;

public class Mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Demotwo temp=new Abs();
		temp.login();
		temp.logout();
		temp.getCompany();
		System.out.println(temp.Demotwo);
	}

}
