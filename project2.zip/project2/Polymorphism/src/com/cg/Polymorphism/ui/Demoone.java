package com.cg.Polymorphism.ui;

public class Demoone   ////////////////////////OVERRIDING	

{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		
		
		//B temp =new B();
	    Y temp = new B();
		
		temp.getAll();
		System.out.println(temp.a);
		
	     //new Y().getAll();
         //Y a=new B();
	
	}

}
class Y        ////child class
{
	static int a=10;
	public void getAll() {
		System.out.println("in Y");

	}
}
class B extends Y
{      
	      ////// parent class
	int a=20;
	public void getAll() {
		super.getAll();
		
		System.out.println("in B");
	}
}
