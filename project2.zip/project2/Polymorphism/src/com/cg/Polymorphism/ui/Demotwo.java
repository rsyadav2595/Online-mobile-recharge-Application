package com.cg.Polymorphism.ui;

public abstract class Demotwo {

	
       double time=9;    ///variable is not abstract 
	public char[] Demotwo;
	
	public abstract void login();      ////abstract method
    public abstract double logout();
	
	public String getCompany()        /////non abstract method
	{
		return "CAPGEMINI";
	}

}
