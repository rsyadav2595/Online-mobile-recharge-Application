package com.cg.Polymorphism.ui;
class Demoinheritance
{  
public static void main(String args[])
{ 
	B temp=new B();
	System.out.println(temp.a);
	temp.getAll();
}

}
class M
{
	int a=10;
	public M() {
		System.out.println("in class A");
	}
	public void getAll()     //method name
	{
		System.out.println("in a class method");
	}
}


  class T extends M
  {
	  
	public T() 
	{
		//super();
		System.out.println("in class B");
	}
}