package com.cg.Polymorphism.ui;

public class Abs extends Demotwo {

	@Override
	public void login() {
		// TODO Auto-generated method stub
		System.out.println("hii in login");
	}

	@Override
	public double logout() {
		// TODO Auto-generated method stub
		return 12.4;
	}

	
	
	
	
}
