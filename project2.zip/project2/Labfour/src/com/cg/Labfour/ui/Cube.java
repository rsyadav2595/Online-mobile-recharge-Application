package com.cg.Labfour.ui;

import java.util.Scanner;

public class Cube 
{

	
	public static void main(String args[])
	{
//	   int sum;
//		int no = 0;
//	System.out.println("Enter the no");
//		Scanner sc=new Scanner(System.in);
//    
//	   
//	sum	=Integer.parseInt(sc.nextLine());
//	
//	int num=sum;
//	int count=0;	
//	while(no>0)
//		
//	{	        int n= no%10;             
//	           System.out.println("Cube of "+n +" is "+(n*n*n));
//                  count=count+1;
//                  no = no/10;
//        
//	}
//      System.out.println(sum);
//	}


	




//
//public class Cube
//{
//		
//	    public static int sumOfSeries(int n) 
//	    { 
//	        int x = (n * (n + 1) / 2);
//			
//	        return x * x; 
//	    } 
//	  
//	    // Driver Function 
//	    public static void main(String[] args) 
//	    { 
//	        int n = 3; 
//	        System.out.println(sumOfSeries(n)); 
//	    } 
//	} 
//
//
long num,temp,digit,sum=0;

Scanner sc=new Scanner(System.in);
System.out.println("Enter the no");
num=sc.nextInt();


temp=num;
while(num>0)
{
	digit=num%10;
	long b=digit*digit*digit;
	sum=sum+b;
	num /=10;
}
System.out.println(sum);


	}
}









