package com.cg.LabFiveExc.ui;



public class User  {

	public void getAll(String name ,String lastname)
	{
		if(name==" "&& lastname==" " )
		{
			 throw new Empexp("Name should not be blank");
		}
			System.out.println(name);
			System.out.println(lastname);
	}

	
	
	
	}
	
	
	
	


