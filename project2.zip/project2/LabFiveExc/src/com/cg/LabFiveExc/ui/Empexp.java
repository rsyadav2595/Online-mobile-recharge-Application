package com.cg.LabFiveExc.ui;

public class Empexp extends RuntimeException {

public Empexp()
{
	
}

public Empexp(String name) 
{
	 
}
}
