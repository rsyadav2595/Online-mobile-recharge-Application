package com.cg.LabFiveExc.ui;

public class Mydemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
try {
		User u=new User();
		u.getAll(" "," yadav");
		
}catch(Empexp e)
{
	System.out.println(e.getMessage());
}
		
	
	}

}
