package com.cg.Mavendemothree;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.OutputStream;



public class Employeedemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employeedemo emp=new Employeedemo();
		InputStream fileread=null;
		Employeedemo empread=null;
		try {
			 fileread=new  FileInputStream("D:/MyDemo.txt");
			 OutputStream filewrite=new FileOutputStream("D:/Myobject.txt");
			
			ObjectInput objectread=new ObjectInputStream(fileread);
						
			objectread.close();
			System.out.println(empread);
			
			
			String data=null;
			//while((data=objectread .readLine())!=null)
			
			
			
		} 
		catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
		
		}
		
		
	}

}
