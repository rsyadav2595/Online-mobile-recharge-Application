package com.cg.LabFiveInt.ui;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n = 0,p=0;
		Scanner scr=new Scanner (System.in);
		System.out.println("Enter the no");
		n=scr.nextInt();
		for(int i =2;i<n;i++)
		{
			//p=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
					p++;
			}
		    if(p==0) {
		    	System.out.println(i);
				
		    }
		    	  
		}
		
}

}
