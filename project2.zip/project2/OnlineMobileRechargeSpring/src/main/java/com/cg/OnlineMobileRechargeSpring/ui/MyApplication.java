package com.cg.OnlineMobileRechargeSpring.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.OnlineMobileRechargeSpring.config.JavaConfig;
import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.Mobile;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;
import com.cg.OnlineMobileRechargeSpring.exception.Mobilerechargeexception;
import com.cg.OnlineMobileRechargeSpring.service.MobileRechargeService;
import com.cg.OnlineMobileRechargeSpring.service.MobileRechargeServiceImpl;

@Component
public class MyApplication {

	@Autowired
	MobileRechargeService mobilerechargeservice;
	static MobileRechargeService service;

	@PostConstruct
	public void init() {
		service = this.mobilerechargeservice;
	}

	public MyApplication() {

	}

	public static void main(String[] args) {

		ApplicationContext appContext = new AnnotationConfigApplicationContext(JavaConfig.class);

		Scanner sc = new Scanner(System.in);
		//service = new MobileRechargeServiceImpl();
		Wallet wallet = (Wallet) appContext.getBean("wallet");

		int choice = 0;
		do {

			printdetails();
			System.out.println("Enter choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:                                           /// Add Customer///
				List<Mobile> mobiles = new ArrayList<Mobile>();
				System.out.println("Enter the name");
				String name = sc.next();
				System.out.println("Enter the email");
				String email = sc.next();
				String choice2 = "yes";
				do {

					Mobile mobi = (Mobile) appContext.getBean("mobi");
					System.out.println("Enter the mobile no");
					BigInteger mobile = sc.nextBigInteger();
					System.out.println("enter operator");
					String operator = sc.next();

					mobi.setMobileno(mobile);
					mobi.setOperator(operator);

					mobiles.add(mobi);
					System.out.println("do you want to add more mobileno enter yes other no");
					choice2 = sc.next();

				} while (choice2.equals("yes"));

				Customer custm = (Customer) appContext.getBean("custm");
				custm.setName(name);
				custm.setEmail(email);
				custm.setMobiles(mobiles);
				service.addCustomer(custm);

				break;

			case 2:                                                          // create wallet or topup balance///

				Customer custmone = (Customer) appContext.getBean("custm");

				Mobile mob = (Mobile) appContext.getBean("mobi");
				// List< Mobile> moblist=new ArrayList<Mobile>();
				System.out.println("Enter walletId");
				BigInteger walletid = sc.nextBigInteger();

				System.out.println("Enter the balance");
				Double balance = sc.nextDouble();

				System.out.println("Enter emailid");
				String emailid = sc.next();

				wallet.setBalance(balance);
				wallet.setWalletId(walletid);
				custmone.setEmail(emailid);

				wallet.setCustomer(custmone);
				wallet.setCustomer(custmone);

				service.topupBalance(wallet);
				System.out.println("----------Wallet create successfuly----------");

				break;

			case 3:                                                                  //// Search By mobileno///

				try {
					Mobile mobbbi = (Mobile) appContext.getBean("mobi");

					System.out.println("Enter mobile no");
					BigInteger mobileno = sc.nextBigInteger();

					Customer mobilesearch = service.searchByMobileno(mobileno);

					System.out.println(mobilesearch);

				} catch (Mobilerechargeexception m) {
					System.out.println(m.getMessage());

				}

				break;

			case 4:                                                               /// Recharge Transaction///

				String choice1 = "yes ";
				List<RechargeTransaction> mylist = new ArrayList<RechargeTransaction>();

				do {
					RechargeTransaction recharge = (RechargeTransaction) appContext.getBean("rechargetransaction");
					System.out.println("Enter transactionId");
					BigInteger transactionid = sc.nextBigInteger();

					System.out.println("Enter mobile no  for recharge");
					BigInteger mobiletwo = sc.nextBigInteger();

					System.out.println("Enter amount for mobile recharge");
					Double amount = sc.nextDouble();
					recharge.setAmount(amount);
					recharge.setMobileno(mobiletwo);
					recharge.setTransactionId(transactionid);
					mylist.add(recharge);
					System.out.println("do u want again recharge yes or no");
					choice1 = sc.next();
				} while (choice1.equals("yes"));
				wallet.setTransaction(mylist);
				service.rechargeMobile(wallet);
				System.out.println("-----------recharge done-------");

				break;

			}
		} while (choice != 6);

	}

	private static void printdetails() {
		System.out.println("1. Add Customer");
		System.out.println("2. Topup balance");
		System.out.println("3. Search by mobile no");
		System.out.println("4. Reacharge mobile no");

	}
}
