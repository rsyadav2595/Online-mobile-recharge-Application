package com.cg.OnlineMobileRechargeSpring.dto;

import java.math.BigInteger;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("rechargetransaction")
@Scope("prototype")
public class RechargeTransaction {

	private BigInteger TransactionId;
	private double amount;
	private BigInteger mobileno;

	public RechargeTransaction() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RechargeTransaction(BigInteger transactionId, double amount, BigInteger mobileno) {
		super();
		TransactionId = transactionId;
		this.amount = amount;
		this.mobileno = mobileno;
	}

	public BigInteger getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(BigInteger transactionId) {
		TransactionId = transactionId;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public BigInteger getMobileno() {
		return mobileno;
	}

	public void setMobileno(BigInteger mobileno) {
		this.mobileno = mobileno;
	}
}
