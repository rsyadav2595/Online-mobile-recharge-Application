package com.cg.OnlineMobileRechargeSpring.service;

import java.math.BigInteger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.OnlineMobileRechargeSpring.dao.MobileRechargeRepository;
import com.cg.OnlineMobileRechargeSpring.dao.MobileRechargeRepositoryImpl;
import com.cg.OnlineMobileRechargeSpring.dto.Customer;
import com.cg.OnlineMobileRechargeSpring.dto.RechargeTransaction;
import com.cg.OnlineMobileRechargeSpring.dto.Wallet;
import com.cg.OnlineMobileRechargeSpring.exception.Mobilerechargeexception;

@Service("mobilerechargeservice")
public class MobileRechargeServiceImpl implements MobileRechargeService {

	@Autowired
	MobileRechargeRepository repository;

	public MobileRechargeServiceImpl() {
		repository = new MobileRechargeRepositoryImpl();
	}

	public boolean addCustomer(Customer custm) {

		if (repository.save(custm)) {
			return true;
		}
		return false;

	}

	public Wallet topupBalance(Wallet wall) {
		// TODO Auto-generated method stub
		return repository.saveWallet(wall);
	}

	public Customer searchByMobileno(BigInteger mobileno) throws Mobilerechargeexception {
		// TODO Auto-generated method stub
		return repository.findByMobileno(mobileno);
	}

	public RechargeTransaction rechargeMobile(Wallet wall) {
		// TODO Auto-generated method stub
		return repository.saveTransaction(wall);
	}

}
