package com.cg.OnlineMobileRechargeSpring.dto;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("wallet")
@Scope("prototype")
public class Wallet {

	private double balance;
	private BigInteger walletId;

	private Customer customer;

	private List<RechargeTransaction> transaction;

	public Wallet(double balance, BigInteger walletId, Customer customer, List<RechargeTransaction> transaction) {
		super();
		this.balance = balance;
		this.walletId = walletId;
		this.customer = customer;
		this.transaction = transaction;
	}

	public Wallet() {
		super();
		// TODO Auto-generated constructor stub
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public BigInteger getWalletId() {
		return walletId;
	}

	public void setWalletId(BigInteger walletId) {
		this.walletId = walletId;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<RechargeTransaction> getTransaction() {
		return transaction;
	}

	public void setTransaction(List<RechargeTransaction> transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + ", walletId=" + walletId + ", customer=" + customer + ", transaction="
				+ transaction + "]";
	}

}